const main = document.querySelector('.main-content');
const appShell = document.querySelector('.app-shell');
const sidebar = document.querySelector('.sidebar');
const toast = document.getElementById('toast');
const dispatchMarkup = main ? main.innerHTML : '';
const licenseModal = document.getElementById('licenseModal');
const licenseForm = document.getElementById('licenseForm');
const licenseError = document.getElementById('licenseFormError');
const quoteModal = document.getElementById('quoteModal');
const quoteForm = document.getElementById('quoteForm');
const quoteError = document.getElementById('quoteFormError');
const quoteEstimateSummary = document.getElementById('quoteEstimateSummary');
const AUTH_TOKEN_KEY = 'rz_dispatch_token';
const MODE_KEY = 'rz_app_mode';
const CUSTOMER_PROFILE_KEY = 'rz_customer_profile';
let state = { jobs: [], drivers: [], activity: [], metrics: {}, analytics: {}, bookings: [], quotes: [] };
let currentUser = null;
let currentMode = localStorage.getItem(MODE_KEY) || 'dispatcher';

function setAppMode(mode) {
  currentMode = mode;
  localStorage.setItem(MODE_KEY, mode);
  if (appShell) { appShell.classList.toggle('customer-mode', mode === 'customer'); appShell.classList.toggle('operator-mode', mode === 'operator'); }
  if (sidebar) sidebar.style.display = mode === 'customer' || mode === 'operator' ? 'none' : '';
  if (main) { main.classList.toggle('customer-main', mode === 'customer'); main.classList.toggle('operator-main', mode === 'operator'); }
}

function updateDispatcherSidebar() {
  if (!sidebar) return;
  sidebar.style.display = currentMode === 'customer' || currentMode === 'operator' ? 'none' : '';
  if (appShell) { appShell.classList.toggle('customer-mode', currentMode === 'customer'); appShell.classList.toggle('operator-mode', currentMode === 'operator'); }
  if (main) { main.classList.toggle('customer-main', currentMode === 'customer'); main.classList.toggle('operator-main', currentMode === 'operator'); }
}

function getAuthToken() {
  return localStorage.getItem(AUTH_TOKEN_KEY) || '';
}

function getDisplayName() {
  if (currentUser && currentUser.name) return currentUser.name;
  if (currentUser && currentUser.email) return currentUser.email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  return 'Dispatcher';
}

function getUserInitials() {
  const name = getDisplayName();
  return name.split(/\s+/).map((part) => part[0]).join('').toUpperCase().slice(0, 2) || 'OP';
}

function updateSidebarUser() {
  const nameEl = document.querySelector('.user-row strong');
  const avatarEl = document.querySelector('.user-row .avatar');
  if (nameEl) nameEl.textContent = getDisplayName();
  if (avatarEl) avatarEl.textContent = getUserInitials();
}

function setAuthToken(token) {
  if (token) localStorage.setItem(AUTH_TOKEN_KEY, token);
  else localStorage.removeItem(AUTH_TOKEN_KEY);
}

function getCustomerProfile() {
  try {
    return JSON.parse(localStorage.getItem(CUSTOMER_PROFILE_KEY) || '{}');
  } catch (error) {
    return {};
  }
}

function saveCustomerProfile(profile) {
  localStorage.setItem(CUSTOMER_PROFILE_KEY, JSON.stringify(profile));
}

async function fetchJson(url, options = {}) {
  const token = getAuthToken();
  const headers = { ...(options.headers || {}) };
  if (!headers['Content-Type'] && !headers['content-type'] && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(url, { ...options, headers });
  if (response.status === 401) {
    setAuthToken('');
    renderAuthScreen();
    throw new Error('Your session expired. Please log in again.');
  }
  if (response.status === 402) {
    openLicenseModal();
  }
  return response;
}

async function checkLicenseStatus() {
  try {
    const response = await fetchJson('/api/license/status');
    const result = await response.json();
    if (!result.locked || result.active) return true;
    openLicenseModal();
    return false;
  } catch (error) {
    return false;
  }
}

function openLicenseModal() {
  if (!licenseModal) return;
  licenseModal.hidden = false;
  const input = document.getElementById('licenseKey');
  if (input) input.focus();
}

function closeLicenseModal() {
  if (!licenseModal) return;
  licenseModal.hidden = true;
  if (licenseForm) licenseForm.reset();
  if (licenseError) licenseError.textContent = '';
}

async function activateLicense(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const key = String(form.get('licenseKey') || '').trim();
  const email = String(form.get('email') || '').trim();

  if (!key && !email) {
    licenseError.textContent = 'Add a valid license key or email to activate.';
    return;
  }

  try {
    const response = await fetchJson('/api/license/activate', {
      method: 'POST',
      body: JSON.stringify(key ? { licenseKey: key } : { email })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'License activation failed');
    closeLicenseModal();
    showToast('License activated');
    await requestOverview();
    renderView(window.location.hash.slice(1) || 'dispatch');
  } catch (error) {
    if (licenseError) licenseError.textContent = error.message;
  }
}

function renderAuthScreen() {
  if (!main) return;
  setAppMode('dispatcher');
  main.innerHTML = `
    <div class="view-header">
      <div>
        <p class="eyebrow">SECURE ACCESS</p>
        <h1>RZ Dispatch</h1>
        <p class="view-subtitle">Choose your workspace and sign in.</p>
      </div>
    </div>
    <section class="panel data-panel empty-panel" style="padding:32px 24px;max-width:560px;">
      <div class="access-mode-switch" style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;">
        <button type="button" class="dispatch-button mode-switch active" data-mode="dispatcher">Dispatcher dashboard</button>
        <button type="button" class="outline-button mode-switch" data-mode="customer">Customer portal</button>
        <button type="button" class="outline-button mode-switch" data-mode="operator">Operator portal</button>
      </div>
      <form id="authForm" style="display:grid;gap:16px;">
        <label style="display:grid;gap:8px;font-weight:700;">Email
          <input id="authEmail" name="email" type="email" placeholder="you@company.com" required style="padding:12px;border:1px solid #dce5e1;border-radius:8px;" />
        </label>
        <label style="display:grid;gap:8px;font-weight:700;">Password
          <input id="authPassword" name="password" type="password" placeholder="••••••••" required style="padding:12px;border:1px solid #dce5e1;border-radius:8px;" />
        </label>
        <div style="display:flex;gap:12px;">
          <button type="submit" class="dispatch-button" style="flex:1;">Sign in</button>
          <button type="button" class="outline-button" id="registerToggle">Create account</button>
        </div>
        <p id="authError" class="form-error" role="alert"></p>
      </form>
    </section>
  `;

  document.querySelectorAll('.mode-switch').forEach((button) => {
    button.addEventListener('click', () => selectAuthMode(button.dataset.mode));
  });

  document.getElementById('registerToggle')?.addEventListener('click', () => {
    const submitButton = document.querySelector('#authForm button[type="submit"]');
    if (submitButton) {
      submitButton.textContent = 'Create account';
      submitButton.dataset.mode = 'register';
    }
  });

  document.getElementById('authForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const email = String(form.get('email') || '').trim();
    const password = String(form.get('password') || '');
    const submitButton = event.currentTarget.querySelector('button[type="submit"]');
    const mode = submitButton?.dataset.mode === 'register' ? 'register' : 'login';
    const portalMode = event.currentTarget.dataset.portalMode || 'dispatcher';
    const resultText = document.getElementById('authError');

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Authentication failed');
      setAuthToken(payload.token);
      currentUser = payload.user || null;
      updateSidebarUser();
      setAppMode(portalMode === 'operator' ? 'operator' : 'dispatcher');
      resultText.textContent = '';
      if (portalMode === 'operator') renderOperatorPortal();
      else {
        await requestOverview();
        renderView(window.location.hash.slice(1) || 'dispatch');
      }
    } catch (error) {
      resultText.textContent = error.message;
    }
  });
}

function showToast(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2800);
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character]));
}

function selectAuthMode(selectedMode) {
  document.querySelectorAll('.mode-switch').forEach((item) => item.classList.toggle('active', item.dataset.mode === selectedMode));
  if (selectedMode === 'customer') {
    setAppMode('customer');
    renderCustomerHome();
  } else if (selectedMode === 'operator') {
    setAppMode('operator');
    const form = document.getElementById('authForm');
    if (form) form.dataset.portalMode = 'operator';
  } else {
    setAppMode('dispatcher');
    renderAuthScreen();
  }
}

async function requestOverview() {
  const response = await fetchJson('/api/overview');
  if (!response.ok) throw new Error('Overview unavailable');
  state = await response.json();
  return state;
}

async function optimizeRoute() {
  const button = document.getElementById('optimizeRoute');
  if (button) { button.disabled = true; button.textContent = 'Optimizing...'; }
  try {
    const previewResponse = await fetchJson('/api/optimization/preview');
    const preview = await previewResponse.json();
    if (!previewResponse.ok) throw new Error(preview.error || 'Could not preview route');
    const activeLoads = preview.jobs.map((job) => `${job.id} (${job.optimizationReason})`).join(' → ');
    const message = activeLoads ? `Suggested order: ${activeLoads}` : 'No active loads to optimize';
    if (!window.confirm(`${message}\n\nApply this route order?`)) return;
    const response = await fetchJson('/api/optimization/apply', { method: 'POST' });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not apply route');
    await requestOverview();
    renderView(window.location.hash.slice(1) || 'dispatch');
    showToast(result.message);
  } catch (error) {
    showToast(error.message);
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Optimize route'; }
  }
}

async function assignJob(id) {
  const button = document.getElementById('dispatchButton');
  if (button) { button.disabled = true; button.textContent = 'Assigning...'; }
  try {
    const response = await fetchJson(`/api/jobs/${encodeURIComponent(id)}/assign`, { method: 'POST' });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not assign this job');
    await requestOverview();
    renderView('dispatch');
    showToast(result.message);
  } catch (error) {
    if (button) { button.disabled = false; button.innerHTML = 'Assign driver <span>→</span>'; }
    showToast(error.message);
  }
}

async function openJobDetail(id) {
  const modal = document.getElementById('jobDetailModal');
  const content = document.getElementById('jobDetailContent');
  const title = document.getElementById('jobDetailTitle');
  const subtitle = document.getElementById('jobDetailSubtitle');
  if (!modal || !content) return;

  modal.hidden = false;
  content.innerHTML = '<div class="detail-loading">Loading live job data...</div>';
  try {
    const response = await fetchJson(`/api/jobs/${encodeURIComponent(id)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Could not load job details');
    const job = payload.job;
    if (title) title.textContent = job.id;
    if (subtitle) subtitle.textContent = `${job.type} · ${job.status === 'assigned' ? 'Assigned' : 'Awaiting driver'}`;
    content.innerHTML = `<div class="detail-status-row"><span class="job-tag">${escapeHTML(job.type)}</span><span class="detail-status ${job.status === 'assigned' ? 'is-assigned' : ''}">${escapeHTML(job.status)}</span></div><div class="detail-route"><div class="detail-route-point"><span class="route-dot from"></span><div><small>FROM</small><strong>${escapeHTML(job.from)}</strong></div></div><div class="detail-route-line"></div><div class="detail-route-point"><span class="route-dot to"></span><div><small>TO</small><strong>${escapeHTML(job.to)}</strong></div></div></div><div class="detail-facts"><div><small>PRIORITY</small><strong>${escapeHTML(job.priority)}</strong></div><div><small>SCHEDULE</small><strong>${escapeHTML(job.time)}</strong></div><div><small>DISTANCE</small><strong>${escapeHTML(job.distance)}</strong></div><div><small>PRICE</small><strong>${escapeHTML(job.price)}</strong></div><div><small>DRIVER</small><strong>${escapeHTML(job.driver || 'Unassigned')}</strong></div></div><div class="detail-actions"><button class="outline-button" id="detailEdit" type="button">Edit load</button><button class="outline-button" id="detailRefresh" type="button">Refresh</button>${job.status === 'assigned' ? '<button class="dispatch-button" disabled>Driver assigned <span>✓</span></button>' : '<button class="dispatch-button" id="detailAssign" type="button">Assign driver <span>→</span></button>'}<button class="danger-button" id="detailDelete" type="button">Delete</button></div>`;
    document.getElementById('detailRefresh')?.addEventListener('click', () => openJobDetail(id));
    document.getElementById('detailAssign')?.addEventListener('click', async () => { closeJobDetail(); await assignJob(id); });
    document.getElementById('detailEdit')?.addEventListener('click', () => renderJobEditForm(job));
    document.getElementById('detailDelete')?.addEventListener('click', () => deleteJob(id));
  } catch (error) {
    content.innerHTML = `<p class="form-error">${escapeHTML(error.message)}</p>`;
  }
}

function renderJobEditForm(job) {
  const content = document.getElementById('jobDetailContent');
  if (!content) return;
  content.innerHTML = `<form id="jobEditForm" class="job-edit-form"><label>Load type<select name="type"><option value="PICKUP" ${job.type === 'PICKUP' ? 'selected' : ''}>Pickup</option><option value="DELIVERY" ${job.type === 'DELIVERY' ? 'selected' : ''}>Delivery</option></select></label><label>Pickup address<input name="from" value="${escapeHTML(job.from)}" maxlength="500" required /></label><label>Delivery address<input name="to" value="${escapeHTML(job.to)}" maxlength="500" required /></label><div class="job-edit-grid"><label>Priority<select name="priority"><option ${job.priority === 'Standard' ? 'selected' : ''}>Standard</option><option ${job.priority === 'High priority' ? 'selected' : ''}>High priority</option><option ${job.priority === 'Urgent' ? 'selected' : ''}>Urgent</option></select></label><label>Status<select name="status"><option value="queued" ${job.status === 'queued' ? 'selected' : ''}>Queued</option><option value="assigned" ${job.status === 'assigned' ? 'selected' : ''}>Assigned</option><option value="completed" ${job.status === 'completed' ? 'selected' : ''}>Completed</option><option value="cancelled" ${job.status === 'cancelled' ? 'selected' : ''}>Cancelled</option></select></label></div><label>Schedule<input name="time" value="${escapeHTML(job.time)}" maxlength="100" required /></label><p class="form-error" id="jobEditError" role="alert"></p><div class="detail-actions"><button class="outline-button" id="cancelJobEdit" type="button">Cancel</button><button class="dispatch-button" type="submit">Save changes <span>✓</span></button></div></form>`;
  document.getElementById('cancelJobEdit')?.addEventListener('click', () => openJobDetail(job.id));
  document.getElementById('jobEditForm')?.addEventListener('submit', (event) => saveJobEdit(event, job.id));
}

async function saveJobEdit(event, id) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const error = document.getElementById('jobEditError');
  try {
    const response = await fetchJson(`/api/jobs/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(Object.fromEntries(form.entries())) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not update load');
    await requestOverview();
    closeJobDetail();
    renderView(window.location.hash.slice(1) || 'dispatch');
    showToast(result.message);
  } catch (requestError) {
    if (error) error.textContent = requestError.message;
  }
}

async function deleteJob(id) {
  if (!window.confirm(`Remove ${id} from the dispatch board?`)) return;
  const response = await fetchJson(`/api/jobs/${encodeURIComponent(id)}`, { method: 'DELETE' });
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Could not remove load');
  await requestOverview();
  closeJobDetail();
  renderView(window.location.hash.slice(1) || 'dispatch');
  showToast(result.message);
}

function closeJobDetail() {
  const modal = document.getElementById('jobDetailModal');
  if (modal) modal.hidden = true;
}

function selectJob(id) {
  const job = state.jobs.find((item) => item.id === id);
  const selectedJob = document.getElementById('selectedJob');
  if (!job || !selectedJob) return;
  document.querySelectorAll('.queue-item').forEach((item) => item.classList.toggle('selected', item.dataset.job === id));
  selectedJob.innerHTML = `<div class="selected-job-top"><div><span class="job-tag">${escapeHTML(job.type)}</span><h3>${escapeHTML(id)}</h3></div><span class="priority">● ${escapeHTML(job.priority)}</span></div><div class="route"><div class="route-line"><span class="route-dot from"></span><span></span><span class="route-dot to"></span></div><div><p><small>FROM</small> ${escapeHTML(job.from)}</p><p><small>TO</small> ${escapeHTML(job.to)}</p></div></div><div class="job-detail"><span>${escapeHTML(job.time)}</span><span>${escapeHTML(job.distance)}</span><span>${escapeHTML(job.price)}</span></div>${job.driver ? `<p class="assigned-driver">Assigned to ${escapeHTML(job.driver)}</p>` : ''}<div class="selected-job-actions"><button class="outline-button" id="viewJobDetails" type="button">View details</button><button class="dispatch-button" id="dispatchButton">${job.status === 'assigned' ? 'Driver assigned' : 'Assign driver'} <span>${job.status === 'assigned' ? '✓' : '→'}</span></button></div>`;
  const button = document.getElementById('dispatchButton');
  if (job.status === 'assigned') { button.disabled = true; button.style.background = 'var(--green)'; }
  else button.addEventListener('click', () => assignJob(id));
  document.getElementById('viewJobDetails')?.addEventListener('click', () => openJobDetail(id));
}

function renderQueue() {
  const list = document.getElementById('queueList');
  if (!list) return;
  const queuedJobs = state.jobs.filter((job) => job.status === 'queued');
  list.innerHTML = queuedJobs.map((job, index) => `<button class="queue-item ${index === 0 ? 'selected' : ''}" data-job="${escapeHTML(job.id)}"><span class="queue-status ${['orange-status', 'blue-status', 'violet-status', 'green-status'][index % 4]}"></span><span class="queue-copy"><strong>${escapeHTML(job.id)}</strong><small>${escapeHTML(job.type[0] + job.type.slice(1).toLowerCase())} · ${escapeHTML(job.from.replace(' Street', ' St'))}</small></span><span class="queue-time">${index === 0 ? 'Now' : `${index * 8} min`}</span></button>`).join('');
  list.querySelectorAll('.queue-item').forEach((item) => item.addEventListener('click', () => selectJob(item.dataset.job)));
  document.querySelectorAll('.map-pin').forEach((pin) => pin.addEventListener('click', () => selectJob(pin.dataset.job)));
  document.querySelector('.queue-count').textContent = queuedJobs.length;
}

async function renderSchedule(selectedDate = 'today') {
  main.innerHTML = '<div class="schedule-loading">Loading live schedule...</div>';
  try {
    const response = await fetchJson(`/api/schedule?date=${encodeURIComponent(selectedDate)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Schedule unavailable');
    const columns = [
      { key: 'queued', label: 'Needs dispatch', tone: 'orange' },
      { key: 'assigned', label: 'Assigned', tone: 'blue' },
      { key: 'completed', label: 'Completed', tone: 'green' }
    ];
    const dateLabel = selectedDate === 'today' ? 'Today' : new Date(`${selectedDate}T12:00:00`).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
    main.innerHTML = `<div class="view-header schedule-header"><div><p class="eyebrow">OPERATIONS PLANNER</p><h1>Schedule board</h1><p class="view-subtitle">Coordinate jobs by status and keep every route moving.</p></div><div class="schedule-actions"><button class="outline-button" id="schedulePrevious" type="button">← Previous</button><button class="small-filter" id="scheduleToday" type="button">${dateLabel}</button><button class="outline-button" id="scheduleNext" type="button">Next →</button><button class="dispatch-button" id="scheduleNewJob" type="button">+ New job</button></div></div><div class="schedule-summary"><span><i class="summary-dot orange"></i>${payload.columns.queued.length} awaiting dispatch</span><span><i class="summary-dot blue"></i>${payload.columns.assigned.length} assigned</span><span><i class="summary-dot green"></i>${payload.columns.completed.length} completed</span><span class="schedule-updated">Updated ${new Date(payload.updatedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span></div><section class="schedule-board">${columns.map((column) => `<article class="schedule-column"><div class="schedule-column-heading"><div><span class="column-kicker ${column.tone}"></span><h2>${column.label}</h2></div><strong>${payload.columns[column.key].length}</strong></div><div class="schedule-cards">${payload.columns[column.key].length ? payload.columns[column.key].map((job) => `<button class="schedule-card" data-job="${escapeHTML(job.id)}"><div class="schedule-card-top"><strong>${escapeHTML(job.id)}</strong><span class="job-tag">${escapeHTML(job.type)}</span></div><div class="schedule-card-route"><span>${escapeHTML(job.from)}</span><b>→</b><span>${escapeHTML(job.to)}</span></div><div class="schedule-card-meta"><span>${escapeHTML(job.time)}</span><span>${escapeHTML(job.distance)}</span><span>${escapeHTML(job.driver || 'Unassigned')}</span></div>${column.key === 'queued' ? '<span class="schedule-card-action">Open and assign →</span>' : '<span class="schedule-card-action">View details →</span>'}</button>`).join('') : '<div class="schedule-empty">No jobs in this lane.</div>'}</div></article>`).join('')}</section>`;

    document.querySelectorAll('.schedule-card').forEach((card) => card.addEventListener('click', () => openJobDetail(card.dataset.job)));
    document.getElementById('scheduleNewJob')?.addEventListener('click', openJobModal);
    document.getElementById('scheduleToday')?.addEventListener('click', () => renderSchedule('today'));
    document.getElementById('schedulePrevious')?.addEventListener('click', () => renderSchedule(shiftScheduleDate(selectedDate, -1)));
    document.getElementById('scheduleNext')?.addEventListener('click', () => renderSchedule(shiftScheduleDate(selectedDate, 1)));
  } catch (error) {
    main.innerHTML = `<div class="empty-state"><strong>Schedule unavailable</strong><p>${escapeHTML(error.message)}</p><button class="outline-button" id="scheduleRetry" type="button">Retry</button></div>`;
    document.getElementById('scheduleRetry')?.addEventListener('click', () => renderSchedule(selectedDate));
  }
}

function shiftScheduleDate(selectedDate, offset) {
  const base = selectedDate === 'today' ? new Date() : new Date(`${selectedDate}T12:00:00`);
  base.setDate(base.getDate() + offset);
  return base.toISOString().slice(0, 10);
}

function formatLiveDate(date = new Date()) {
  return new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).format(date).toUpperCase();
}

function getGreeting(date = new Date()) {
  const hour = date.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function renderLiveDateAndGreeting() {
  const stamp = document.getElementById('liveDateStamp');
  const greeting = document.getElementById('liveGreeting');
  if (stamp) stamp.textContent = formatLiveDate();
  if (greeting) {
    const name = getDisplayName().split(' ')[0];
    const hour = new Date().getHours();
    const currentGreeting = getGreeting();
    greeting.innerHTML = `${currentGreeting}, ${escapeHTML(name)} <span>✦</span>`;
    greeting.title = `Local time: ${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
  }
  updateSidebarUser();
}

function renderMapPins() {
  const liveJobs = state.jobs.slice(0, 4);
  document.querySelectorAll('.map-pin').forEach((pin, index) => {
    const job = liveJobs[index] || liveJobs[0];
    if (!job) return;
    const marker = job.priority === 'High priority' ? '▴' : job.type === 'DELIVERY' ? '●' : '▾';
    const eta = `${Math.max(4, 12 + ((index + 1) * 6) - (Date.now() % 10))} min`;
    pin.innerHTML = `<span>${marker}</span><strong>${String(index + 1).padStart(2, '0')}</strong>`;
    pin.title = `${job.id} · ${job.from} → ${job.to} · ${eta}`;
    pin.dataset.job = job.id;
  });
}

function renderMetrics() {
  const values = [state.metrics.active, state.metrics.onRoad, String(state.metrics.available).padStart(2, '0'), `${state.metrics.eta} min`];
  document.querySelectorAll('#dispatch .metric-card>strong').forEach((element, index) => {
    if (index === 3) element.innerHTML = `${escapeHTML(state.metrics.eta)} <em>min</em>`;
    else element.textContent = values[index];
  });
}

function bindDispatch() {
  renderLiveDateAndGreeting();
  renderMapPins();
  renderQueue();
  renderMetrics();
  selectJob(state.jobs[0]?.id);
  document.getElementById('optimizeRoute')?.addEventListener('click', optimizeRoute);
  document.getElementById('newJob')?.addEventListener('click', openJobModal);
  document.getElementById('dashboardSearch')?.addEventListener('click', searchDashboard);
  document.getElementById('dashboardNotifications')?.addEventListener('click', showDashboardNotifications);
  document.querySelector('.queue-heading .text-button')?.addEventListener('click', () => { window.location.hash = 'schedule'; });
  document.querySelector('.activity-panel .text-button')?.addEventListener('click', () => { window.location.hash = 'analytics'; });
  const mapCanvas = document.getElementById('mapCanvas');
  const mapButtons = document.querySelectorAll('.map-tools .small-icon');
  mapButtons[0]?.addEventListener('click', () => { if (mapCanvas) mapCanvas.style.transform = 'scale(1)'; showToast('Map recentered'); });
  mapButtons[1]?.addEventListener('click', () => updateMapZoom(0.1));
  mapButtons[2]?.addEventListener('click', () => updateMapZoom(-0.1));
  document.getElementById('performanceRefresh')?.addEventListener('click', async () => { await requestOverview(); renderMetrics(); showToast('Performance data refreshed'); });
}

async function searchDashboard() {
  const query = window.prompt('Search jobs, customers, or services');
  if (!query || !query.trim()) return;
  const response = await fetchJson(`/api/search?q=${encodeURIComponent(query.trim())}`);
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Search unavailable');
  if (!result.results.length) return showToast('No matching records found');
  showToast(result.results.slice(0, 3).map((item) => item.label).join(' · '));
}

async function showDashboardNotifications() {
  const response = await fetchJson('/api/notifications');
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Notifications unavailable');
  if (!result.notifications.length) return showToast('No unread notifications');
  showToast(result.notifications.map((item) => item.subject).join(' · '));
}

function updateMapZoom(delta) {
  const mapCanvas = document.getElementById('mapCanvas');
  if (!mapCanvas) return;
  const current = Number(mapCanvas.dataset.zoom || 1);
  const next = Math.min(1.35, Math.max(.8, current + delta));
  mapCanvas.dataset.zoom = next.toFixed(2);
  mapCanvas.style.transform = `scale(${next})`;
  mapCanvas.style.transformOrigin = 'center';
}

function openJobModal() {
  const modal = document.getElementById('jobModal');
  const form = document.getElementById('jobForm');
  modal.hidden = false;
  document.getElementById('jobFrom').focus();
}

function closeJobModal() {
  const modal = document.getElementById('jobModal');
  modal.hidden = true;
  document.getElementById('jobForm').reset();
  document.getElementById('jobFormError').textContent = '';
}

async function createJob(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const type = form.get('type');
  const from = String(form.get('from') || '').trim();
  const to = String(form.get('to') || '').trim();
  const error = document.getElementById('jobFormError');
  if (!from || !to) { error.textContent = 'Add both pickup and delivery addresses.'; return; }
  try {
    const response = await fetchJson('/api/jobs', { method: 'POST', body: JSON.stringify({ type, from, to }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not create this job');
    closeJobModal();
    await requestOverview();
    renderView('dispatch');
    showToast(`${result.job.id} created`);
  } catch (requestError) {
    error.textContent = requestError.message;
  }
}

function renderFleet(title = 'Fleet') {
  main.innerHTML = `<div class="view-header"><div><p class="eyebrow">OPERATIONS</p><h1>${title}</h1><p class="view-subtitle">Live vehicle availability and job coverage.</p></div><button class="outline-button" id="fleetRefresh">Refresh fleet</button></div><section class="metric-grid compact-grid"><article class="metric-card"><div class="metric-top"><span>VEHICLES</span><span class="metric-icon blue">◉</span></div><strong>${state.drivers.length}</strong><div class="metric-foot">West Coast fleet</div></article><article class="metric-card"><div class="metric-top"><span>ON ROUTE</span><span class="metric-icon orange">↗</span></div><strong>${state.drivers.filter((driver) => driver.status === 'On route').length}</strong><div class="metric-foot">Active vehicles</div></article><article class="metric-card"><div class="metric-top"><span>AVAILABLE</span><span class="metric-icon green">✓</span></div><strong>${state.metrics.available}</strong><div class="metric-foot">Ready for dispatch</div></article></section><section class="panel data-panel"><div class="panel-heading"><div><p class="eyebrow">LIVE ROSTER</p><h2>Vehicles and drivers</h2></div><span class="live-pill"><i></i> Live</span></div><div class="data-table">${state.drivers.map((driver) => `<div class="data-row"><span class="activity-avatar blue-bg">${escapeHTML(driver.initials)}</span><div><strong>${escapeHTML(driver.name)}</strong><small>${escapeHTML(driver.vehicle)} · ${driver.jobs} jobs today</small></div><span class="status-text ${driver.status === 'Available' ? 'is-green' : ''}">${escapeHTML(driver.status)}</span><strong class="row-rating">★ ${escapeHTML(driver.rating)}</strong></div>`).join('')}</div></section>`;
  document.getElementById('fleetRefresh').addEventListener('click', async () => { await requestOverview(); renderView('fleet'); showToast('Fleet data refreshed'); });
}

function renderAnalytics() {
  const analytics = state.analytics;
  main.innerHTML = `<div class="view-header"><div><p class="eyebrow">PERFORMANCE</p><h1>Analytics</h1><p class="view-subtitle">A live readout of the same dispatch activity.</p></div><button class="small-filter" id="analyticsRefresh">Today⌄</button></div><section class="metric-grid compact-grid"><article class="metric-card"><div class="metric-top"><span>COMPLETED</span><span class="metric-icon green">✓</span></div><strong>${analytics.completed}</strong><div class="metric-foot"><span class="up">↑ 6.4%</span> vs yesterday</div></article><article class="metric-card"><div class="metric-top"><span>ON-TIME RATE</span><span class="metric-icon blue">◈</span></div><strong>${analytics.onTimeRate}<em>%</em></strong><div class="metric-foot">Target 90%</div></article><article class="metric-card"><div class="metric-top"><span>UTILIZATION</span><span class="metric-icon violet">◷</span></div><strong>${analytics.utilization}<em>%</em></strong><div class="metric-foot">Fleet capacity used</div></article><article class="metric-card"><div class="metric-top"><span>DISTANCE</span><span class="metric-icon orange">↗</span></div><strong>${escapeHTML(analytics.distance)}</strong><div class="metric-foot">Across active jobs</div></article></section><section class="panel data-panel"><div class="panel-heading"><div><p class="eyebrow">OPERATIONS LOG</p><h2>Recent activity</h2></div></div><div class="activity-list">${state.activity.slice(0, 8).map((item, index) => `<div class="activity-row"><span class="activity-avatar ${['orange-bg', 'blue-bg', 'violet-bg'][index % 3]}">${escapeHTML(item.initials)}</span><div><strong>${escapeHTML(item.name)} <span>${escapeHTML(item.action)}</span></strong><small>${escapeHTML(item.detail)}</small></div><time>${escapeHTML(item.time)}</time></div>`).join('')}</div></section>`;
  document.getElementById('analyticsRefresh')?.addEventListener('click', async () => { await requestOverview(); renderAnalytics(); showToast('Analytics refreshed'); });
}

async function renderInbox() {
  main.innerHTML = '<div class="schedule-loading">Loading communication center...</div>';
  try {
    const response = await fetchJson('/api/messages');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Messages unavailable');
    const messages = payload.messages;
    const unreadBadge = document.querySelector('.alert-count');
    if (unreadBadge) unreadBadge.textContent = payload.unread;
    const firstMessage = messages[0];
    main.innerHTML = `<div class="view-header"><div><p class="eyebrow">OPERATIONS COMMS</p><h1>Communication center</h1><p class="view-subtitle">Keep dispatch, fleet, and customer conversations in one place.</p></div><button class="dispatch-button" id="composeMessage" type="button">+ New message</button></div><section class="communication-layout"><div class="panel message-list-panel"><div class="message-list-heading"><strong>Inbox</strong><span>${payload.unread} unread</span></div><div class="message-list" id="messageList">${messages.length ? messages.map((message) => `<button class="message-row ${message.isRead ? '' : 'is-unread'}" data-message="${escapeHTML(message.id)}"><span class="activity-avatar ${message.type === 'fleet' ? 'blue-bg' : message.type === 'system' ? 'violet-bg' : 'orange-bg'}">${escapeHTML(message.initials)}</span><span class="message-row-copy"><strong>${escapeHTML(message.subject)}</strong><small>${escapeHTML(message.sender)} · ${escapeHTML(message.body.slice(0, 58))}${message.body.length > 58 ? '...' : ''}</small></span><span class="message-time">${formatMessageTime(message.createdAt)}</span></button>`).join('') : '<div class="empty-state">No messages yet.</div>'}</div></div><article class="panel message-reader" id="messageReader">${firstMessage ? renderMessageReader(firstMessage) : '<div class="empty-state"><strong>Your inbox is clear</strong><p>New operational messages will appear here.</p></div>'}</article></section>`;
    document.querySelectorAll('.message-row').forEach((row) => row.addEventListener('click', () => openMessage(messages.find((message) => message.id === row.dataset.message))));
    document.getElementById('composeMessage')?.addEventListener('click', () => renderComposeMessage());
  } catch (error) {
    main.innerHTML = `<div class="empty-state"><strong>Communication center unavailable</strong><p>${escapeHTML(error.message)}</p><button class="outline-button" id="messagesRetry" type="button">Retry</button></div>`;
    document.getElementById('messagesRetry')?.addEventListener('click', renderInbox);
  }
}

function formatMessageTime(value) {
  const date = new Date(value);
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function renderMessageReader(message) {
  return `<div class="message-reader-heading"><div><span class="eyebrow">${escapeHTML(message.type)}</span><h2>${escapeHTML(message.subject)}</h2><p>From ${escapeHTML(message.sender)} · ${formatMessageTime(message.createdAt)}</p></div><span class="activity-avatar orange-bg">${escapeHTML(message.initials)}</span></div><div class="message-body">${escapeHTML(message.body)}</div><div class="message-reader-actions"><button class="outline-button" id="replyMessage" type="button">Reply</button><button class="outline-button" id="archiveMessage" type="button">Mark read</button></div>`;
}

async function openMessage(message) {
  if (!message) return;
  const reader = document.getElementById('messageReader');
  if (reader) reader.innerHTML = renderMessageReader(message);
  if (!message.isRead) {
    await fetchJson(`/api/messages/${encodeURIComponent(message.id)}/read`, { method: 'PATCH' });
    message.isRead = 1;
    document.querySelector(`.message-row[data-message="${CSS.escape(message.id)}"]`)?.classList.remove('is-unread');
  }
  document.getElementById('replyMessage')?.addEventListener('click', () => renderComposeMessage(message));
  document.getElementById('archiveMessage')?.addEventListener('click', async () => {
    message.isRead = 1;
    document.querySelector(`.message-row[data-message="${CSS.escape(message.id)}"]`)?.classList.remove('is-unread');
    showToast('Message marked read');
  });
}

function renderComposeMessage(replyTo = null) {
  const reader = document.getElementById('messageReader');
  if (!reader) return;
  reader.innerHTML = `<div class="message-reader-heading"><div><span class="eyebrow">NEW MESSAGE</span><h2>${replyTo ? `Reply to ${escapeHTML(replyTo.sender)}` : 'Compose message'}</h2><p>Send an update to the operations inbox.</p></div></div><form id="messageForm" class="message-form"><label>Subject<input name="subject" value="${replyTo ? `Re: ${escapeHTML(replyTo.subject)}` : ''}" maxlength="160" required /></label><label>Message<textarea name="body" rows="7" maxlength="1000" placeholder="Write an operational update..." required>${replyTo ? `\n\n--- Original message ---\n${escapeHTML(replyTo.body)}` : ''}</textarea></label><p class="form-error" id="messageFormError" role="alert"></p><div class="detail-actions"><button class="outline-button" id="cancelMessage" type="button">Cancel</button><button class="dispatch-button" type="submit">Send message <span>→</span></button></div></form>`;
  document.getElementById('cancelMessage')?.addEventListener('click', renderInbox);
  document.getElementById('messageForm')?.addEventListener('submit', sendMessage);
}

async function sendMessage(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const error = document.getElementById('messageFormError');
  try {
    const response = await fetchJson('/api/messages', { method: 'POST', body: JSON.stringify({ subject: form.get('subject'), body: form.get('body') }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not send message');
    showToast('Message sent');
    await renderInbox();
  } catch (requestError) {
    if (error) error.textContent = requestError.message;
  }
}

function renderSimpleView(title, subtitle, content) {
  main.innerHTML = `<div class="view-header"><div><p class="eyebrow">WORKSPACE</p><h1>${title}</h1><p class="view-subtitle">${subtitle}</p></div></div><section class="panel data-panel empty-panel">${content}</section>`;
}

function renderCustomerHome() {
  setAppMode('customer');
  if (!main) return;
  main.innerHTML = `
    <div class="customer-shell">
      <div class="customer-topbar"><div class="brand"><span class="brand-mark">R</span><span>RZ DISPATCH</span></div><div class="customer-top-actions"><button class="outline-button" id="customerSettings" type="button">My preferences</button><button class="outline-button" id="customerSignOut" type="button">Sign out</button></div></div>
      <section class="customer-hero">
        <div class="customer-hero-copy">
          <p class="eyebrow">RZ travel services</p>
          <h1>Private transport that feels effortless.</h1>
          <p>Book airport rides, same-day trips, executive travel, and hourly charters with real-time tracking and reliable dispatch.</p>
          <div class="customer-hero-actions">
            <button class="dispatch-button" type="button" id="customerBookNow">Book a trip</button>
            <button class="outline-button" type="button" id="customerTrackOrder">Track an order</button>
          </div>
          <div class="customer-hero-badges">
            <span>✔ Trusted by 12k+ riders</span>
            <span>✔ Fully insured</span>
            <span>✔ Live support</span>
          </div>
        </div>
        <div class="customer-hero-panel panel">
          <p class="eyebrow">Popular routes</p>
          <ul>
            <li><strong>SFO → Downtown</strong><span>From $79</span></li>
            <li><strong>OAK → Business district</strong><span>From $68</span></li>
            <li><strong>SJC → Bayfront</strong><span>From $88</span></li>
            <li><strong>Hourly charter</strong><span>From $120/hr</span></li>
          </ul>
        </div>
      </section>
      <section class="customer-service-grid">
        <article class="customer-card panel">
          <p class="eyebrow">Airport transfers</p>
          <h3>Flight-aware service</h3>
          <p>On-time pickups with live flight tracking and priority check-in.</p>
        </article>
        <article class="customer-card panel">
          <p class="eyebrow">Same-day rides</p>
          <h3>Fast local trips</h3>
          <p>Last-minute rides, errands, and quick business pickups with live ETAs.</p>
        </article>
        <article class="customer-card panel">
          <p class="eyebrow">Hourly charter</p>
          <h3>Flexible by the hour</h3>
          <p>Multi-stop trips, events, and group travel tailored to your schedule.</p>
        </article>
      </section>
      <section class="customer-trust panel">
        <div class="trust-row">
          <div><strong>4.9/5</strong><span>Customer rating</span></div>
          <div><strong>24/7</strong><span>Support</span></div>
          <div><strong>100%</strong><span>Verified drivers</span></div>
          <div><strong>12k+</strong><span>Trips completed</span></div>
        </div>
      </section>
      <section class="customer-options panel">
        <div><p class="eyebrow">SELF-SERVICE</p><h2>Manage your customer options</h2><p>Save your contact details and ride preferences for faster booking.</p></div>
        <button class="outline-button" id="customerSettingsSecondary" type="button">Manage profile and preferences</button>
      </section>
    </div>
  `;

  document.getElementById('customerBookNow')?.addEventListener('click', () => {
    openQuoteModal();
  });
  document.getElementById('customerTrackOrder')?.addEventListener('click', () => {
    renderCustomerPortal();
  });
  document.getElementById('customerSettings')?.addEventListener('click', renderCustomerSettings);
  document.getElementById('customerSettingsSecondary')?.addEventListener('click', renderCustomerSettings);
  document.getElementById('customerSignOut')?.addEventListener('click', signOutToDispatcher);
}

function signOutToDispatcher() {
  setAuthToken('');
  setAppMode('dispatcher');
  window.location.hash = 'dispatch';
  renderAuthScreen();
}

async function openOperatorPortalForSession() {
  try {
    const response = await fetchJson('/api/auth/me');
    const payload = await response.json();
    if (response.ok && payload.user && payload.user.role === 'operator' && payload.user.driverId) {
      renderOperatorPortal();
      return;
    }
  } catch (error) {
    // Token missing/expired or network failure — fall through to a clean operator sign-in.
  }
  // The stored session is not an operator session (e.g. admin/owner) or is invalid.
  // Drop it and show the sign-in screen with the Operator portal tab selected instead of
  // surfacing a confusing "Operator access required" error on the route.
  setAuthToken('');
  setAppMode('operator');
  renderAuthScreen();
  selectAuthMode('operator');
}

async function renderOperatorPortal() {
  setAppMode('operator');
  if (!main) return;
  main.innerHTML = '<div class="operator-loading">Loading your route...</div>';
  try {
    const response = await fetchJson('/api/operator/jobs');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Operator portal unavailable');
    const jobs = payload.jobs || [];
    main.innerHTML = `<div class="operator-shell"><header class="operator-topbar"><div><p class="eyebrow">OPERATOR PORTAL</p><h1>Good to go, ${escapeHTML(payload.operator.name.split(' ')[0])}</h1><p>${escapeHTML(payload.operator.driverId)} · Your assigned route</p></div><button class="operator-icon-button" id="operatorSignOut" type="button" aria-label="Sign out">↪</button></header><section class="operator-summary"><div><span>ASSIGNED LOADS</span><strong>${jobs.length}</strong></div><div><span>ACTIVE</span><strong>${jobs.filter((job) => !['completed', 'cancelled'].includes(job.status)).length}</strong></div><div><span>VEHICLE</span><strong>${escapeHTML(getOperatorVehicle(payload.operator.driverId))}</strong></div></section><section class="operator-section"><div class="operator-section-heading"><div><p class="eyebrow">TODAY'S ROUTE</p><h2>Assigned jobs</h2></div><button class="operator-refresh" id="operatorRefresh" type="button">Refresh</button></div><div class="operator-job-list">${jobs.length ? jobs.map((job) => renderOperatorJobCard(job)).join('') : '<div class="operator-empty"><strong>No assigned jobs</strong><p>Your dispatcher will add jobs to your route here.</p></div>'}</div></section></div>`;
    document.getElementById('operatorSignOut')?.addEventListener('click', signOutToDispatcher);
    document.getElementById('operatorRefresh')?.addEventListener('click', renderOperatorPortal);
    document.querySelectorAll('.operator-job-card').forEach((card) => card.addEventListener('click', () => openOperatorJob(card.dataset.job)));
  } catch (error) {
    const needsOperatorSignIn = /(access required|authentication required|session expired|invalid session)/i.test(String(error.message || ''));
    const signInHint = needsOperatorSignIn
      ? '<p>This browser is signed in with a non-operator account. Use the operator account (operator@rzdispatch.local) to open the operator portal.</p>'
      : '';
    main.innerHTML = `<div class="operator-empty"><strong>Could not load route</strong><p>${escapeHTML(error.message)}</p>${signInHint}<button class="operator-primary" id="operatorRetry" type="button">Retry</button></div>`;
    document.getElementById('operatorRetry')?.addEventListener('click', renderOperatorPortal);
  }
}

function getOperatorVehicle(driverId) {
  return { 'DR-101': 'Van 12', 'DR-102': 'Van 08', 'DR-103': 'Truck 21', 'DR-104': 'Van 04' }[driverId] || 'Assigned vehicle';
}

function renderOperatorJobCard(job) {
  const statusLabel = job.status.replace(/_/g, ' ');
  return `<button class="operator-job-card" data-job="${escapeHTML(job.id)}" type="button"><div class="operator-job-card-top"><strong>${escapeHTML(job.id)}</strong><span class="operator-status ${job.status}">${escapeHTML(statusLabel)}</span></div><div class="operator-route"><span class="operator-route-dot pickup"></span><div><small>PICKUP</small><strong>${escapeHTML(job.from)}</strong></div><span class="operator-route-line"></span><span class="operator-route-dot dropoff"></span><div><small>DROPOFF</small><strong>${escapeHTML(job.to)}</strong></div></div><div class="operator-job-meta"><span>${escapeHTML(job.time)}</span><span>${escapeHTML(job.distance)}</span><span>${escapeHTML(job.priority)}</span></div></button>`;
}

async function openOperatorJob(id) {
  const response = await fetchJson(`/api/operator/jobs/${encodeURIComponent(id)}`);
  const payload = await response.json();
  if (!response.ok) return showToast(payload.error || 'Job unavailable');
  const job = payload.job;
  const nextStatus = { assigned: 'en_route', en_route: 'arrived', arrived: 'picked_up', picked_up: 'delivered' }[job.status];
  main.innerHTML = `<div class="operator-shell operator-detail-shell"><header class="operator-topbar"><button class="operator-back" id="operatorBack" type="button">←</button><div><p class="eyebrow">JOB DETAIL</p><h1>${escapeHTML(job.id)}</h1><p>${escapeHTML(job.priority)} · ${escapeHTML(job.time)}</p></div><button class="operator-icon-button" id="operatorSignOut" type="button" aria-label="Sign out">↪</button></header><section class="operator-detail-card"><span class="operator-status ${job.status}">${escapeHTML(job.status.replace(/_/g, ' '))}</span><div class="operator-detail-route"><div><small>PICKUP</small><strong>${escapeHTML(job.from)}</strong></div><div class="operator-detail-connector"></div><div><small>DROPOFF</small><strong>${escapeHTML(job.to)}</strong></div></div><div class="operator-facts"><div><span>DISTANCE</span><strong>${escapeHTML(job.distance)}</strong></div><div><span>FARE</span><strong>${escapeHTML(job.price)}</strong></div><div><span>DRIVER</span><strong>${escapeHTML(job.driver || 'Assigned to you')}</strong></div></div></section><section class="operator-action-card"><p class="eyebrow">JOB PROGRESS</p><h2>Update delivery status</h2><p class="operator-muted">Status changes are sequential and recorded for dispatch.</p>${nextStatus ? `<button class="operator-primary" id="operatorAdvance" type="button">Mark ${nextStatus.replace(/_/g, ' ')} <span>→</span></button>` : '<div class="operator-complete">Delivery complete</div>'}</section><section class="operator-action-card"><p class="eyebrow">PROOF OF DELIVERY</p><h2>Scan or upload document</h2><p class="operator-muted">Capture a signed document or delivery photo. JPG, PNG, and PDF up to 3 MB.</p><input class="operator-file-input" id="operatorProofFile" type="file" accept="image/jpeg,image/png,application/pdf" capture="environment" /><div id="operatorProofList">${payload.proof.length ? payload.proof.map((proof) => `<div class="operator-proof-row"><span>✓</span><strong>${escapeHTML(proof.fileName)}</strong><small>${Math.round(proof.byteSize / 1024)} KB</small></div>`).join('') : '<p class="operator-muted">No proof uploaded yet.</p>'}</div></section></div>`;
  document.getElementById('operatorBack')?.addEventListener('click', renderOperatorPortal);
  document.getElementById('operatorSignOut')?.addEventListener('click', signOutToDispatcher);
  document.getElementById('operatorAdvance')?.addEventListener('click', () => advanceOperatorStatus(job.id, nextStatus));
  document.getElementById('operatorProofFile')?.addEventListener('change', (event) => uploadOperatorProof(job.id, event.target.files[0]));
}

async function advanceOperatorStatus(id, status) {
  const response = await fetchJson(`/api/operator/jobs/${encodeURIComponent(id)}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Could not update status');
  showToast(result.message);
  openOperatorJob(id);
}

async function uploadOperatorProof(jobId, file) {
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) return showToast('Proof document must be smaller than 3 MB');
  const reader = new FileReader();
  reader.onload = async () => {
    const response = await fetchJson(`/api/operator/jobs/${encodeURIComponent(jobId)}/proof`, { method: 'POST', body: JSON.stringify({ fileName: file.name, mimeType: file.type, data: reader.result }) });
    const result = await response.json();
    if (!response.ok) return showToast(result.error || 'Could not upload proof');
    showToast(result.message);
    openOperatorJob(jobId);
  };
  reader.readAsDataURL(file);
}

function renderCustomerSettings() {
  const profile = getCustomerProfile();
  if (!main) return;
  setAppMode('customer');
  main.innerHTML = `<div class="customer-shell customer-panel-shell"><div class="customer-back-row"><button type="button" class="outline-button" id="customerSettingsBack">← Back home</button><button type="button" class="outline-button" id="customerSignOut">Sign out</button></div><section class="panel customer-settings-panel"><div class="view-header"><div><p class="eyebrow">CUSTOMER PROFILE</p><h1>My preferences</h1><p class="view-subtitle">Keep your booking details ready and choose how RZ Dispatch supports you.</p></div></div><form id="customerSettingsForm" class="customer-settings-form"><div class="customer-settings-grid"><label>Full name<input name="name" value="${escapeHTML(profile.name || '')}" placeholder="Maria Lopez" required /></label><label>Email<input name="email" type="email" value="${escapeHTML(profile.email || '')}" placeholder="maria@company.com" required /></label><label>Phone<input name="phone" type="tel" value="${escapeHTML(profile.phone || '')}" placeholder="(415) 555-0191" required /></label><label>Preferred vehicle<select name="vehicleType"><option value="car" ${profile.vehicleType === 'car' ? 'selected' : ''}>Car</option><option value="suv" ${profile.vehicleType === 'suv' ? 'selected' : ''}>SUV</option><option value="van" ${profile.vehicleType === 'van' ? 'selected' : ''}>Van</option><option value="luxury" ${profile.vehicleType === 'luxury' ? 'selected' : ''}>Luxury</option></select></label><label>Passengers<input name="passengers" type="number" min="1" max="12" value="${escapeHTML(profile.passengers || '2')}" required /></label></div><label class="customer-checkbox"><input name="notifications" type="checkbox" ${profile.notifications !== false ? 'checked' : ''} /> Send me booking and driver updates</label><p class="form-error" id="customerSettingsError" role="alert"></p><div class="modal-actions"><button type="button" class="outline-button" id="customerSettingsCancel">Cancel</button><button type="submit" class="dispatch-button">Save preferences <span>✓</span></button></div></form></section></div>`;
  document.getElementById('customerSettingsBack')?.addEventListener('click', renderCustomerHome);
  document.getElementById('customerSettingsCancel')?.addEventListener('click', renderCustomerHome);
  document.getElementById('customerSignOut')?.addEventListener('click', signOutToDispatcher);
  document.getElementById('customerSettingsForm')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    saveCustomerProfile({ name: String(form.get('name') || '').trim(), email: String(form.get('email') || '').trim(), phone: String(form.get('phone') || '').trim(), vehicleType: String(form.get('vehicleType') || 'car'), passengers: String(form.get('passengers') || '2'), notifications: form.get('notifications') === 'on' });
    showToast('Preferences saved');
    renderCustomerHome();
  });
}

function renderCustomerPortal() {
  if (!main) return;
  main.innerHTML = `
    <div class="customer-shell customer-panel-shell">
      <div class="customer-back-row">
        <button type="button" class="outline-button" id="customerBackHome">← Back home</button>
        <button type="button" class="outline-button" id="customerSignOut">Sign out</button>
      </div>
      <section class="panel data-panel" style="padding:24px;max-width:760px;margin:0 auto;">
        <div class="view-header" style="margin-bottom:18px;">
          <div>
            <p class="eyebrow">CUSTOMER PORTAL</p>
            <h1>Order tracking</h1>
            <p class="view-subtitle">Look up your quote or booking using your order ID and email.</p>
          </div>
        </div>
        <form id="customerPortalForm" style="display:grid;gap:14px;">
          <label style="display:grid;gap:8px;font-weight:700;">Order ID
            <input name="orderId" type="text" placeholder="Q-AB12CD34" required style="padding:12px;border:1px solid #dce5e1;border-radius:8px;" />
          </label>
          <label style="display:grid;gap:8px;font-weight:700;">Email
            <input name="email" type="email" placeholder="customer@example.com" required style="padding:12px;border:1px solid #dce5e1;border-radius:8px;" />
          </label>
          <button class="dispatch-button" type="submit">Track order</button>
          <p id="customerPortalError" class="form-error" role="alert"></p>
        </form>
        <div id="customerPortalResult" class="booking-grid" style="margin-top:18px;"></div>
      </section>
    </div>
  `;

  document.getElementById('customerBackHome')?.addEventListener('click', renderCustomerHome);
  document.getElementById('customerSignOut')?.addEventListener('click', signOutToDispatcher);

  document.getElementById('customerPortalForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const orderId = String(form.get('orderId') || '').trim();
    const email = String(form.get('email') || '').trim();
    const error = document.getElementById('customerPortalError');
    const resultBox = document.getElementById('customerPortalResult');
    if (!orderId || !email) {
      if (error) error.textContent = 'Enter both an order ID and email.';
      return;
    }

    try {
      const response = await fetch(`/api/customer/order?orderId=${encodeURIComponent(orderId)}&email=${encodeURIComponent(email)}`);
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'We could not find that order.');
      if (error) error.textContent = '';
      resultBox.innerHTML = `
        <article class="booking-card">
          <div class="booking-card-top">
            <div>
              <strong>${escapeHTML(payload.customerName)}</strong>
              <small>${escapeHTML(payload.kind.toUpperCase())} · ${escapeHTML(payload.id)}</small>
            </div>
            <span class="booking-badge">${escapeHTML(payload.status)}</span>
          </div>
          <div class="booking-meta">
            <div><span>Service</span><strong>${escapeHTML(payload.serviceType.replace(/-/g, ' '))}</strong></div>
            <div><span>Pickup</span><strong>${escapeHTML(payload.pickupAddress)}</strong></div>
            <div><span>Total</span><strong>$${Number(payload.quoteTotal || 0).toFixed(2)}</strong></div>
          </div>
          <div class="quote-estimate" style="margin-top:16px;">
            <div class="quote-lines">
              <div><strong>Tracking status:</strong> ${escapeHTML(payload.tracking.step)}</div>
              <div>${escapeHTML(payload.tracking.message)}</div>
            </div>
            <div class="quote-total">
              <span>Progress</span>
              <span>${payload.tracking.progress}%</span>
            </div>
          </div>
        </article>
      `;
    } catch (err) {
      if (error) error.textContent = err.message;
      resultBox.innerHTML = '';
    }
  });
}

async function renderServicePages() {
  main.innerHTML = '<div class="schedule-loading">Loading service configuration...</div>';
  try {
    const response = await fetchJson('/api/services');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Service configuration unavailable');
    const services = payload.services || [];
    main.innerHTML = `<div class="view-header"><div><p class="eyebrow">ADMIN CONFIGURATION</p><h1>Services and pricing</h1><p class="view-subtitle">Create service offerings, control availability, and manage the pricing rules used by quotes.</p></div><button class="dispatch-button" id="newServiceButton" type="button">+ New service</button></div><section class="service-admin-summary"><article class="panel"><strong>${services.length}</strong><span>configured services</span></article><article class="panel"><strong>${services.filter((service) => service.active).length}</strong><span>customer-visible</span></article><article class="panel"><strong>$${services.reduce((sum, service) => sum + service.basePrice, 0).toFixed(2)}</strong><span>base price portfolio</span></article></section><section class="panel service-admin-panel"><div class="panel-heading"><div><p class="eyebrow">CATALOG</p><h2>Service catalog</h2></div><button class="small-filter" id="refreshServices" type="button">Refresh</button></div><div class="service-admin-list">${services.length ? services.map((service) => `<div class="service-admin-row"><div class="service-admin-name"><span class="service-state ${service.active ? 'active' : ''}"></span><div><strong>${escapeHTML(service.name)}</strong><small>${escapeHTML(service.key)} · ${escapeHTML(service.description)}</small></div></div><div class="service-admin-prices"><span>Base <strong>$${service.basePrice.toFixed(2)}</strong></span><span>Per mile <strong>$${service.distanceRate.toFixed(2)}</strong></span><span>Hourly <strong>$${service.hourlyRate.toFixed(2)}</strong></span></div><span class="service-admin-status ${service.active ? 'is-active' : ''}">${service.active ? 'Active' : 'Hidden'}</span><div class="service-admin-actions"><button class="outline-button service-edit" data-service="${escapeHTML(service.key)}" type="button">Edit</button><button class="danger-button service-delete" data-service="${escapeHTML(service.key)}" type="button">Delete</button></div></div>`).join('') : '<div class="empty-state">No services configured.</div>'}</div></section><section class="panel service-editor" id="serviceEditor" hidden></section>`;
    document.getElementById('newServiceButton')?.addEventListener('click', () => renderServiceEditor());
    document.getElementById('refreshServices')?.addEventListener('click', renderServicePages);
    document.querySelectorAll('.service-edit').forEach((button) => button.addEventListener('click', () => renderServiceEditor(services.find((service) => service.key === button.dataset.service))));
    document.querySelectorAll('.service-delete').forEach((button) => button.addEventListener('click', () => deleteService(button.dataset.service)));
  } catch (error) {
    main.innerHTML = `<div class="empty-state"><strong>Services unavailable</strong><p>${escapeHTML(error.message)}</p><button class="outline-button" id="servicesRetry" type="button">Retry</button></div>`;
    document.getElementById('servicesRetry')?.addEventListener('click', renderServicePages);
  }
}

function renderServiceEditor(service = {}) {
  const editor = document.getElementById('serviceEditor');
  if (!editor) return;
  editor.hidden = false;
  const editing = Boolean(service.key);
  editor.innerHTML = `<div class="service-editor-header"><div><p class="eyebrow">${editing ? 'EDIT SERVICE' : 'NEW SERVICE'}</p><h2>${editing ? escapeHTML(service.name) : 'Create service'}</h2></div><button class="modal-close" id="cancelServiceEdit" type="button">&times;</button></div><form id="serviceForm" class="service-form"><label>Service key<input name="key" value="${escapeHTML(service.key || '')}" ${editing ? 'readonly' : ''} placeholder="corporate-shuttle" required /></label><label>Display name<input name="name" value="${escapeHTML(service.name || '')}" placeholder="Corporate shuttle" required /></label><label>Description<textarea name="description" rows="3" maxlength="300" required>${escapeHTML(service.description || '')}</textarea></label><div class="service-price-grid"><label>Base price<input name="basePrice" type="number" min="0" step="0.01" value="${service.basePrice ?? 0}" required /></label><label>Per-mile rate<input name="distanceRate" type="number" min="0" step="0.01" value="${service.distanceRate ?? 0}" required /></label><label>Hourly rate<input name="hourlyRate" type="number" min="0" step="0.01" value="${service.hourlyRate ?? 0}" required /></label></div><label class="service-active-toggle"><input name="active" type="checkbox" ${service.active !== false ? 'checked' : ''} /> Available to customers</label><p class="form-error" id="serviceFormError" role="alert"></p><div class="detail-actions"><button class="outline-button" id="cancelServiceButton" type="button">Cancel</button><button class="dispatch-button" type="submit">Save service <span>✓</span></button></div></form>`;
  document.getElementById('cancelServiceEdit')?.addEventListener('click', () => { editor.hidden = true; });
  document.getElementById('cancelServiceButton')?.addEventListener('click', () => { editor.hidden = true; });
  document.getElementById('serviceForm')?.addEventListener('submit', (event) => saveService(event, service.key));
  editor.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function saveService(event, originalKey = '') {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const data = Object.fromEntries(form.entries());
  data.active = form.get('active') === 'on';
  const method = originalKey ? 'PATCH' : 'POST';
  const endpoint = originalKey ? `/api/services/${encodeURIComponent(originalKey)}` : '/api/services';
  const error = document.getElementById('serviceFormError');
  try {
    const response = await fetchJson(endpoint, { method, body: JSON.stringify(data) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not save service');
    showToast('Service configuration saved');
    await renderServicePages();
  } catch (requestError) {
    if (error) error.textContent = requestError.message;
  }
}

async function deleteService(key) {
  if (!window.confirm(`Delete the ${key} service configuration?`)) return;
  const response = await fetchJson(`/api/services/${encodeURIComponent(key)}`, { method: 'DELETE' });
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Could not delete service');
  showToast('Service deleted');
  renderServicePages();
}

async function renderCoveragePage() {
  main.innerHTML = '<div class="schedule-loading">Loading coverage rules...</div>';
  try {
    const response = await fetchJson('/api/coverage/zones');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Coverage configuration unavailable');
    const zones = payload.zones || [];
    main.innerHTML = `<div class="view-header"><div><p class="eyebrow">OPERATIONS CONFIGURATION</p><h1>Coverage management</h1><p class="view-subtitle">Configure geofenced service regions, regional pricing, and fleet availability rules.</p></div><button class="dispatch-button" id="newZoneButton" type="button">+ Add region</button></div><section class="coverage-admin-summary"><article class="panel"><strong>${zones.length}</strong><span>configured regions</span></article><article class="panel"><strong>${zones.filter((zone) => zone.active).length}</strong><span>active regions</span></article><article class="panel"><strong>$${zones.reduce((sum, zone) => sum + zone.baseSurcharge, 0).toFixed(2)}</strong><span>base surcharge exposure</span></article></section><section class="panel coverage-admin-panel"><div class="panel-heading"><div><p class="eyebrow">GEOFENCE RULES</p><h2>Service zones</h2></div><button class="small-filter" id="refreshZones" type="button">Refresh</button></div><div class="zone-admin-list">${zones.length ? zones.map((zone) => `<div class="zone-admin-row"><div class="zone-admin-name"><span class="zone-state ${zone.active ? 'active' : ''}"></span><div><strong>${escapeHTML(zone.name)}</strong><small>${escapeHTML(zone.key)} · ${escapeHTML(zone.boundary)}</small></div></div><div class="zone-admin-prices"><span>Base <strong>+$${zone.baseSurcharge.toFixed(2)}</strong></span><span>Per mile <strong>+$${zone.distanceSurcharge.toFixed(2)}</strong></span></div><span class="zone-admin-status ${zone.active ? 'is-active' : ''}">${zone.active ? 'Active' : 'Inactive'}</span><div class="zone-admin-actions"><button class="outline-button zone-edit" data-zone="${escapeHTML(zone.key)}" type="button">Edit</button><button class="danger-button zone-delete" data-zone="${escapeHTML(zone.key)}" type="button">Delete</button></div></div>`).join('') : '<div class="empty-state">No service zones configured.</div>'}</div></section><section class="panel zone-editor" id="zoneEditor" hidden></section>`;
    document.getElementById('newZoneButton')?.addEventListener('click', () => renderZoneEditor());
    document.getElementById('refreshZones')?.addEventListener('click', renderCoveragePage);
    document.querySelectorAll('.zone-edit').forEach((button) => button.addEventListener('click', () => renderZoneEditor(zones.find((zone) => zone.key === button.dataset.zone))));
    document.querySelectorAll('.zone-delete').forEach((button) => button.addEventListener('click', () => deleteZone(button.dataset.zone)));
  } catch (error) {
    main.innerHTML = `<div class="empty-state"><strong>Coverage unavailable</strong><p>${escapeHTML(error.message)}</p><button class="outline-button" id="coverageRetry" type="button">Retry</button></div>`;
    document.getElementById('coverageRetry')?.addEventListener('click', renderCoveragePage);
  }
}

function renderZoneEditor(zone = {}) {
  const editor = document.getElementById('zoneEditor');
  if (!editor) return;
  editor.hidden = false;
  const editing = Boolean(zone.key);
  editor.innerHTML = `<div class="zone-editor-header"><div><p class="eyebrow">${editing ? 'EDIT GEOFENCE' : 'NEW GEOFENCE'}</p><h2>${editing ? escapeHTML(zone.name) : 'Create service region'}</h2></div><button class="modal-close" id="cancelZoneEdit" type="button">&times;</button></div><form id="zoneForm" class="zone-form"><label>Region key<input name="key" value="${escapeHTML(zone.key || '')}" ${editing ? 'readonly' : ''} placeholder="peninsula-east" required /></label><label>Region name<input name="name" value="${escapeHTML(zone.name || '')}" placeholder="Peninsula East" required /></label><label>Boundary / geofence coordinates<textarea name="boundary" rows="3" placeholder="lat,lng;lat,lng" required>${escapeHTML(zone.boundary || '')}</textarea><small>Use semicolon-separated latitude,longitude points or a polygon identifier.</small></label><div class="zone-price-grid"><label>Base surcharge<input name="baseSurcharge" type="number" min="0" step="0.01" value="${zone.baseSurcharge ?? 0}" required /></label><label>Per-mile surcharge<input name="distanceSurcharge" type="number" min="0" step="0.01" value="${zone.distanceSurcharge ?? 0}" required /></label></div><label class="zone-active-toggle"><input name="active" type="checkbox" ${zone.active !== false ? 'checked' : ''} /> Region is active for dispatch and quoting</label><p class="form-error" id="zoneFormError" role="alert"></p><div class="detail-actions"><button class="outline-button" id="cancelZoneButton" type="button">Cancel</button><button class="dispatch-button" type="submit">Save region <span>✓</span></button></div></form>`;
  document.getElementById('cancelZoneEdit')?.addEventListener('click', () => { editor.hidden = true; });
  document.getElementById('cancelZoneButton')?.addEventListener('click', () => { editor.hidden = true; });
  document.getElementById('zoneForm')?.addEventListener('submit', (event) => saveZone(event, zone.key));
  editor.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function saveZone(event, originalKey = '') {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const data = Object.fromEntries(form.entries());
  data.active = form.get('active') === 'on';
  const method = originalKey ? 'PATCH' : 'POST';
  const endpoint = originalKey ? `/api/coverage/zones/${encodeURIComponent(originalKey)}` : '/api/coverage/zones';
  const error = document.getElementById('zoneFormError');
  try {
    const response = await fetchJson(endpoint, { method, body: JSON.stringify(data) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not save region');
    showToast('Coverage rules saved');
    await renderCoveragePage();
  } catch (requestError) {
    if (error) error.textContent = requestError.message;
  }
}

async function deleteZone(key) {
  if (!window.confirm(`Delete the ${key} geofence?`)) return;
  const response = await fetchJson(`/api/coverage/zones/${encodeURIComponent(key)}`, { method: 'DELETE' });
  const result = await response.json();
  if (!response.ok) return showToast(result.error || 'Could not delete region');
  showToast('Region deleted');
  renderCoveragePage();
}

function renderQuoteEstimate(estimate) {
  if (!quoteEstimateSummary || !estimate) return;
  quoteEstimateSummary.innerHTML = `
    <div class="quote-lines">
      <div><strong>${escapeHTML(estimate.serviceType.replace(/-/g, ' '))}</strong> · ${escapeHTML(estimate.vehicleType)} · ${escapeHTML(String(estimate.miles))} miles</div>
      <div>Base: $${estimate.breakdown.base.toFixed(2)}</div>
      <div>Distance: $${estimate.breakdown.distanceRate.toFixed(2)}</div>
      <div>Passengers: $${estimate.breakdown.passengerSurcharge.toFixed(2)}</div>
      <div>Service fee: $${estimate.breakdown.serviceFee.toFixed(2)}</div>
      <div>Tax: $${estimate.breakdown.tax.toFixed(2)}</div>
    </div>
    <div class="quote-total"><span>Estimated total</span><span>$${estimate.total.toFixed(2)}</span></div>
  `;
}

function openQuoteModal() {
  if (!quoteModal) return;
  quoteModal.hidden = false;
  const profile = getCustomerProfile();
  const profileFields = {
    customerName: profile.name,
    email: profile.email,
    phone: profile.phone,
    vehicleType: profile.vehicleType,
    passengers: profile.passengers
  };
  Object.entries(profileFields).forEach(([name, value]) => {
    const field = document.querySelector(`#quoteForm [name="${name}"]`);
    if (field && value && !field.value) field.value = value;
  });
  const dateInput = document.querySelector('#quoteForm input[name="serviceDate"]');
  if (dateInput && !dateInput.value) {
    const nextDate = new Date(Date.now() + 86400000);
    dateInput.value = nextDate.toISOString().slice(0, 10);
  }
  const firstField = document.querySelector('#quoteForm input[name="customerName"]');
  if (firstField) firstField.focus();
}

function closeQuoteModal() {
  if (!quoteModal) return;
  quoteModal.hidden = true;
  if (quoteForm) quoteForm.reset();
  if (quoteError) quoteError.textContent = '';
  if (quoteEstimateSummary) quoteEstimateSummary.innerHTML = '';
}

async function estimateQuoteFromForm(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  const miles = Number(payload.miles || 0);
  const passengers = Number(payload.passengers || 1);
  const hours = Number(payload.hours || 1);

  try {
    const response = await fetchJson('/api/quotes/estimate', {
      method: 'POST',
      body: JSON.stringify({ ...payload, miles, passengers, hours })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Unable to estimate quote');
    renderQuoteEstimate(result.estimate);
    return result.estimate;
  } catch (error) {
    if (quoteError) quoteError.textContent = error.message;
    return null;
  }
}

async function submitBooking(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  const miles = Number(payload.miles || 0);
  const passengers = Number(payload.passengers || 1);
  const hours = Number(payload.hours || 1);

  try {
    const response = await fetchJson('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({ ...payload, miles, passengers, hours })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Unable to create booking');
    closeQuoteModal();
    await requestOverview();
    renderView('bookings');
    showToast(`Booking ${result.booking.id} confirmed`);
  } catch (error) {
    if (quoteError) quoteError.textContent = error.message;
  }
}

async function renderBookings() {
  let quotes = [];
  let bookings = [];

  try {
    const quotesResponse = await fetchJson('/api/quotes');
    const quotesPayload = await quotesResponse.json();
    if (quotesResponse.ok) quotes = Array.isArray(quotesPayload.quotes) ? quotesPayload.quotes : [];
  } catch (error) {
    quotes = [];
  }

  try {
    const bookingsResponse = await fetchJson('/api/bookings');
    const bookingsPayload = await bookingsResponse.json();
    if (bookingsResponse.ok) bookings = Array.isArray(bookingsPayload.bookings) ? bookingsPayload.bookings : [];
  } catch (error) {
    bookings = [];
  }

  main.innerHTML = `
    <div class="view-header">
      <div>
        <p class="eyebrow">BOOKINGS</p>
        <h1>Booking and quote engine</h1>
        <p class="view-subtitle">Track estimates, confirm reservations, and manage customer requests.</p>
      </div>
      <button class="outline-button" id="newQuoteButton" type="button">New quote</button>
    </div>
    <section class="booking-grid">
      <article class="panel data-panel">
        <div class="panel-heading">
          <div><p class="eyebrow">BOOKINGS</p><h2>Confirmed reservations</h2></div>
          <button class="small-filter" id="refreshBookings">Refresh</button>
        </div>
        <div class="data-table">
          ${bookings.length ? bookings.map((booking) => `
            <div class="booking-card">
              <div class="booking-card-top">
                <div>
                  <strong>${escapeHTML(booking.customerName)}</strong>
                  <small>${escapeHTML(booking.serviceType.replace(/-/g, ' '))} · ${escapeHTML(booking.vehicleType)}</small>
                </div>
                <span class="booking-badge">${escapeHTML(booking.status)}</span>
              </div>
              <div class="booking-meta">
                <div><span>ID</span><strong>${escapeHTML(booking.id)}</strong></div>
                <div><span>Pickup</span><strong>${escapeHTML(booking.pickupAddress)}</strong></div>
                <div><span>Total</span><strong>$${Number(booking.quoteTotal || 0).toFixed(2)}</strong></div>
              </div>
            </div>
          `).join('') : '<div class="empty-list">No bookings have been created yet.</div>'}
        </div>
      </article>
      <article class="panel data-panel">
        <div class="panel-heading">
          <div><p class="eyebrow">QUOTES</p><h2>Pending estimates</h2></div>
        </div>
        <div class="data-table">
          ${quotes.length ? quotes.map((quote) => `
            <div class="booking-card">
              <div class="booking-card-top">
                <div>
                  <strong>${escapeHTML(quote.customerName)}</strong>
                  <small>${escapeHTML(quote.serviceType.replace(/-/g, ' '))} · ${escapeHTML(quote.serviceDate)}</small>
                </div>
                <span class="booking-badge">${escapeHTML(quote.status)}</span>
              </div>
              <div class="booking-meta">
                <div><span>Route</span><strong>${escapeHTML(quote.pickupAddress)}</strong></div>
                <div><span>To</span><strong>${escapeHTML(quote.dropoffAddress)}</strong></div>
                <div><span>Estimate</span><strong>$${Number(quote.quoteTotal || 0).toFixed(2)}</strong></div>
              </div>
            </div>
          `).join('') : '<div class="empty-list">No quotes are waiting for approval.</div>'}
        </div>
      </article>
    </section>
  `;

  document.getElementById('newQuoteButton')?.addEventListener('click', openQuoteModal);
  document.getElementById('refreshBookings')?.addEventListener('click', () => renderBookings());
}

async function renderCRM() {
  main.innerHTML = '<div class="schedule-loading">Loading customer relationship management...</div>';
  try {
    const response = await fetchJson('/api/crm/customers');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'CRM data unavailable');
    const customers = payload.customers || [];
    main.innerHTML = `<div class="view-header"><div><p class="eyebrow">RELATIONSHIP MANAGEMENT</p><h1>Customer CRM</h1><p class="view-subtitle">Manage your team’s customer relationships, contacts, and service history.</p></div><button class="outline-button" id="crmRefresh" type="button">Refresh directory</button></div><section class="crm-toolbar panel"><div><strong>${customers.length}</strong><span>registered customers</span></div><div><strong>${customers.reduce((sum, customer) => sum + customer.bookings, 0)}</strong><span>completed bookings</span></div><div><strong>$${customers.reduce((sum, customer) => sum + customer.totalSpend, 0).toFixed(2)}</strong><span>customer revenue</span></div><label class="crm-search"><span>Search</span><input id="crmSearch" type="search" placeholder="Name, email, or phone" /></label></section><section class="crm-layout"><article class="panel crm-directory"><div class="panel-heading"><div><p class="eyebrow">CUSTOMER DIRECTORY</p><h2>Registered customers</h2></div><span class="live-pill"><i></i> Live</span></div><div class="crm-customer-list" id="crmCustomerList">${customers.length ? customers.map((customer, index) => `<button class="crm-customer-row ${index === 0 ? 'selected' : ''}" data-customer="${escapeHTML(customer.id)}"><span class="activity-avatar ${['orange-bg', 'blue-bg', 'violet-bg'][index % 3]} ">${escapeHTML(customer.name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase())}</span><span><strong>${escapeHTML(customer.name)}</strong><small>${escapeHTML(customer.email)} · ${customer.bookings} bookings</small></span><span class="crm-customer-total">$${customer.totalSpend.toFixed(2)}</span></button>`).join('') : '<div class="empty-state"><strong>No customers yet</strong><p>Customers appear after quotes or bookings are created.</p></div>'}</div></article><article class="panel crm-profile" id="crmProfile">${customers[0] ? renderCRMProfile(customers[0]) : '<div class="empty-state">Select a customer to view their relationship history.</div>'}</article></section>`;
    const renderSelectedCustomer = (customer) => {
      document.querySelectorAll('.crm-customer-row').forEach((row) => row.classList.toggle('selected', row.dataset.customer === customer.id));
      const profile = document.getElementById('crmProfile');
      if (profile) profile.innerHTML = renderCRMProfile(customer);
    };
    document.querySelectorAll('.crm-customer-row').forEach((row) => row.addEventListener('click', () => renderSelectedCustomer(customers.find((customer) => customer.id === row.dataset.customer))));
    document.getElementById('crmSearch')?.addEventListener('input', (event) => {
      const query = event.target.value.toLowerCase().trim();
      document.querySelectorAll('.crm-customer-row').forEach((row) => { row.hidden = !row.textContent.toLowerCase().includes(query); });
    });
    document.getElementById('crmRefresh')?.addEventListener('click', renderCRM);
  } catch (error) {
    main.innerHTML = `<div class="empty-state"><strong>CRM unavailable</strong><p>${escapeHTML(error.message)}</p><button class="outline-button" id="crmRetry" type="button">Retry</button></div>`;
    document.getElementById('crmRetry')?.addEventListener('click', renderCRM);
  }
}

function renderCRMProfile(customer) {
  return `<div class="crm-profile-header"><div><p class="eyebrow">CUSTOMER PROFILE</p><h2>${escapeHTML(customer.name)}</h2><p>${escapeHTML(customer.id)} · Last contact ${formatMessageTime(customer.lastContact)}</p></div><span class="activity-avatar blue-bg">${escapeHTML(customer.name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase())}</span></div><div class="crm-contact-grid"><div><small>EMAIL</small><a href="mailto:${escapeHTML(customer.email)}">${escapeHTML(customer.email)}</a></div><div><small>PHONE</small><a href="tel:${escapeHTML(customer.phone)}">${escapeHTML(customer.phone || 'Not provided')}</a></div><div><small>BOOKINGS</small><strong>${customer.bookings}</strong></div><div><small>QUOTES</small><strong>${customer.quotes}</strong></div><div><small>TOTAL SPEND</small><strong>$${customer.totalSpend.toFixed(2)}</strong></div></div><div class="crm-history"><div class="panel-heading"><div><p class="eyebrow">RELATIONSHIP HISTORY</p><h3>Customer activity</h3></div></div>${customer.history.length ? customer.history.map((item) => `<div class="crm-history-row"><span class="crm-history-marker ${item.kind === 'booking' ? 'is-booking' : ''}"></span><div><strong>${escapeHTML(item.kind === 'booking' ? 'Booking' : 'Quote')} · ${escapeHTML(item.id)}</strong><small>${escapeHTML(item.serviceType.replace(/-/g, ' '))} · ${escapeHTML(item.date)}</small><p>${escapeHTML(item.route)}</p></div><span class="booking-badge">${escapeHTML(item.status)}</span></div>`).join('') : '<div class="empty-state">No relationship history yet.</div>'}</div>`;
}

async function renderSettings() {
  let summary = {
    plan: 'Lifetime',
    licenseStatus: 'Active',
    role: 'owner',
    billing: { type: 'Lifetime', status: 'Active', amount: '$499.00', cycle: 'One-time purchase' },
    workspace: 'West Coast Fleet',
    email: 'owner@company.com'
  };

  try {
    const response = await fetchJson('/api/account/summary');
    if (response.ok) summary = await response.json();
  } catch (error) {
    // keep default summary if the backend is not available
  }

  let adminOverview = null;
  if (summary.role === 'admin') {
    try {
      const response = await fetchJson('/api/admin/overview');
      if (response.ok) adminOverview = await response.json();
    } catch (error) {
      // admin overview is optional for a failed request
    }
  }

  let billingSummary = null;
  if (summary.role === 'admin') {
    try {
      const response = await fetchJson('/api/admin/billing');
      if (response.ok) billingSummary = await response.json();
    } catch (error) {
      // billing summary is optional
    }
  }

  const billingCards = billingSummary ? `
    <div class="metric-grid compact-grid" style="margin-top:20px;">
      <article class="metric-card"><div class="metric-top"><span>BILLING PLAN</span><span class="metric-icon blue">◉</span></div><strong>${escapeHTML(billingSummary.plan)}</strong><div class="metric-foot">${escapeHTML(billingSummary.amount)}</div></article>
      <article class="metric-card"><div class="metric-top"><span>MRR</span><span class="metric-icon green">✓</span></div><strong>${escapeHTML(billingSummary.monthlyRecurringRevenue)}</strong><div class="metric-foot">Monthly recurring</div></article>
      <article class="metric-card"><div class="metric-top"><span>ACTIVE CUSTOMERS</span><span class="metric-icon violet">◷</span></div><strong>${escapeHTML(String(billingSummary.activeCustomers))}</strong><div class="metric-foot">Collection: ${escapeHTML(billingSummary.collectionStatus)}</div></article>
    </div>
  ` : '';

  const adminCards = adminOverview ? `
    <div class="metric-grid compact-grid premium-metrics" style="margin-top:20px;">
      <article class="metric-card premium-metric"><div class="metric-top"><span>TOTAL USERS</span><span class="metric-icon blue">◉</span></div><strong>${adminOverview.totalUsers}</strong><div class="metric-foot">Active tenant accounts</div></article>
      <article class="metric-card premium-metric"><div class="metric-top"><span>ACTIVE LICENSES</span><span class="metric-icon green">✓</span></div><strong>${adminOverview.activeLicenses}</strong><div class="metric-foot">Paid customers</div></article>
      <article class="metric-card premium-metric"><div class="metric-top"><span>REVENUE</span><span class="metric-icon violet">◷</span></div><strong>$${adminOverview.totalRevenue}</strong><div class="metric-foot">${adminOverview.currency}</div></article>
    </div>
  ` : '';

  main.innerHTML = `
    <div class="view-header">
      <div>
        <p class="eyebrow">ACCOUNT</p>
        <h1>Workspace settings</h1>
        <p class="view-subtitle">Your ${summary.workspace} SaaS details and operating status.</p>
      </div>
      <div class="header-actions">
        <button class="outline-button" id="verifyEmailButton" type="button">Verify email</button>
        <button class="outline-button" id="signOutButton" type="button">Sign out</button>
      </div>
    </div>

    <section class="settings-shell">
      <div class="settings-hero panel">
        <div class="settings-hero-copy">
          <p class="eyebrow">PLAN STATUS</p>
          <h2>${summary.plan}</h2>
          <p class="settings-hero-text">Your workspace is online and fully provisioned for operational dispatch.</p>
        </div>
        <div class="settings-hero-meta">
          <span class="live-pill"><i></i> ${summary.licenseStatus}</span>
          <div class="hero-badge">${escapeHTML(summary.billing.amount)}</div>
        </div>
      </div>

      <div class="settings-grid">
        <article class="panel settings-panel">
          <div class="panel-heading compact-heading">
            <div>
              <p class="eyebrow">WORKSPACE</p>
              <h2>Overview</h2>
            </div>
          </div>
          <div class="data-table settings-table">
            <div class="data-row"><span>Workspace</span><strong>${escapeHTML(summary.workspace)}</strong></div>
            <div class="data-row"><span>Billing</span><strong>${escapeHTML(summary.billing.type)} · ${escapeHTML(summary.billing.amount)} ${escapeHTML(summary.billing.cycle)}</strong></div>
            <div class="data-row"><span>Role</span><strong>${escapeHTML(summary.role)}</strong></div>
            <div class="data-row"><span>Email</span><strong>${escapeHTML(summary.email || 'owner@company.com')}</strong></div>
          </div>
        </article>

        <article class="panel settings-panel accent-panel">
          <div class="panel-heading compact-heading">
            <div>
              <p class="eyebrow">SECURITY</p>
              <h2>Access control</h2>
            </div>
          </div>
          <ul class="security-list">
            <li><span class="security-dot green"></span> JWT authentication enabled</li>
            <li><span class="security-dot blue"></span> License enforcement active</li>
            <li><span class="security-dot violet"></span> Role-based access ready</li>
            <li><span class="security-dot orange"></span> Email verification available</li>
          </ul>
        </article>
      </div>

      ${billingCards || adminCards}
    </section>
  `;

  document.getElementById('verifyEmailButton')?.addEventListener('click', async () => {
    try {
      const response = await fetchJson('/api/auth/verify-email', { method: 'POST' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Unable to generate verification token');
      showToast('Verification token generated');
      console.log('Verification token:', result.token);
    } catch (error) {
      showToast(error.message);
    }
  });

  document.getElementById('signOutButton')?.addEventListener('click', () => {
    setAuthToken('');
    renderAuthScreen();
    showToast('Signed out');
  });
}

function renderView(view) {
  document.querySelectorAll('.nav-item').forEach((item) => item.classList.toggle('active', item.getAttribute('href') === `#${view}`));
  if (view === 'dispatch') { main.innerHTML = dispatchMarkup; main.id = 'dispatch'; bindDispatch(); return; }
  main.id = view;
  if (view === 'schedule') renderSchedule();
  else if (view === 'fleet') renderFleet();
  else if (view === 'drivers') renderFleet('Drivers');
  else if (view === 'bookings') renderBookings();
  else if (view === 'services') renderServicePages();
  else if (view === 'coverage') renderCoveragePage();
  else if (view === 'crm') renderCRM();
  else if (view === 'analytics') renderAnalytics();
  else if (view === 'inbox') renderInbox();
  else if (view === 'settings') renderSettings();
  else renderSimpleView('Settings', 'Workspace preferences for West Coast Fleet.', '<div class="empty-state"><strong>Workspace is live</strong><p>Fleet data is connected to the Relay backend.</p></div>');
}

document.querySelectorAll('.nav-item[href^="#"]').forEach((item) => item.addEventListener('click', (event) => { event.preventDefault(); window.location.hash = item.getAttribute('href').slice(1); }));
window.addEventListener('hashchange', () => renderView(window.location.hash.slice(1) || 'dispatch'));
window.addEventListener('load', () => renderLiveDateAndGreeting());
setInterval(() => {
  renderLiveDateAndGreeting();
  if (document.getElementById('dispatch') && state.jobs.length) {
    renderMapPins();
    renderQueue();
  }
}, 30000);

document.getElementById('closeJobModal')?.addEventListener('click', closeJobModal);
document.getElementById('cancelJob')?.addEventListener('click', closeJobModal);
document.getElementById('jobForm')?.addEventListener('submit', createJob);
document.getElementById('jobModal')?.addEventListener('click', (event) => { if (event.target.id === 'jobModal') closeJobModal(); });
document.getElementById('requestQuoteButton')?.addEventListener('click', openQuoteModal);
document.getElementById('closeQuoteModal')?.addEventListener('click', closeQuoteModal);
document.getElementById('estimateQuoteButton')?.addEventListener('click', estimateQuoteFromForm);
quoteForm?.addEventListener('submit', submitBooking);
document.getElementById('quoteModal')?.addEventListener('click', (event) => { if (event.target.id === 'quoteModal') closeQuoteModal(); });
document.getElementById('closeLicenseModal')?.addEventListener('click', closeLicenseModal);
document.getElementById('cancelLicense')?.addEventListener('click', closeLicenseModal);
licenseForm?.addEventListener('submit', activateLicense);
document.getElementById('closeJobDetail')?.addEventListener('click', closeJobDetail);
document.getElementById('jobDetailModal')?.addEventListener('click', (event) => { if (event.target.id === 'jobDetailModal') closeJobDetail(); });
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && document.getElementById('jobModal') && !document.getElementById('jobModal').hidden) closeJobModal();
  if (event.key === 'Escape' && licenseModal && !licenseModal.hidden) closeLicenseModal();
  if (event.key === 'Escape' && quoteModal && !quoteModal.hidden) closeQuoteModal();
  if (event.key === 'Escape' && document.getElementById('jobDetailModal') && !document.getElementById('jobDetailModal').hidden) closeJobDetail();
});

async function initializeApp() {
  updateDispatcherSidebar();
  const storedMode = localStorage.getItem(MODE_KEY) || 'dispatcher';
  if (storedMode === 'customer') {
    renderCustomerHome();
    return;
  }

  const token = getAuthToken();
  if (!token) {
    renderAuthScreen();
    return;
  }

  if (storedMode === 'operator') {
    try {
      const meResponse = await fetchJson('/api/auth/me');
      if (meResponse.ok) currentUser = (await meResponse.json()).user;
    } catch (error) { /* session will be handled by the portal */ }
    updateSidebarUser();
    await openOperatorPortalForSession();
    return;
  }

  const allowed = await checkLicenseStatus();
  if (!allowed) return;

  try {
    await requestOverview();
    const meResponse = await fetchJson('/api/auth/me');
    if (meResponse.ok) currentUser = (await meResponse.json()).user;
    updateSidebarUser();
    renderView(window.location.hash.slice(1) || 'dispatch');
  } catch (error) {
    showToast('Start the backend with npm start to load live data');
  }
}

initializeApp();
