'use strict';

/**
 * PostgreSQL database layer for RZ Dispatch.
 *
 * Replaces the old better-sqlite3 synchronous connection with an async
 * `pg` (node-postgres) connection pool while keeping a very similar API:
 *
 *   await db.get(sql, ...params)  -> single row object or undefined
 *   await db.all(sql, ...params)  -> array of row objects
 *   await db.run(sql, ...params)  -> { changes, lastInsertRowid }
 *   await db.exec(sql, ...params) -> alias of run (schema DDL)
 *   await db.transaction(fn)      -> runs fn(tx) inside BEGIN/COMMIT
 *   await db.close()              -> releases the pool
 *
 * SQL written for SQLite uses `?` placeholders; they are converted to
 * PostgreSQL `$1, $2, ...` here so the application SQL did not need to change.
 * JS booleans are mapped to 0/1 (the schema stores flag columns as SMALLINT,
 * matching the previous SQLite behaviour) and `undefined` to NULL.
 *
 * The schema plus seed data are created lazily on the first query through
 * `db.setInitializer(fn)` — this keeps both `node server.js` and `node --test`
 * working without any extra bootstrapping.
 */

require('dotenv').config();
const { Pool } = require('pg');

function buildConnectionConfig() {
  const connectionString = process.env.DATABASE_URL || process.env.PG_CONNECTION_STRING || '';

  const config = {
    // Friendly local defaults so the app boots against a default local install.
    host: process.env.PGHOST || '127.0.0.1',
    port: Number(process.env.PGPORT) || 5432,
    database: process.env.PGDATABASE || 'rz_dispatch',
    user: process.env.PGUSER || 'postgres',
    password: process.env.PGPASSWORD || 'postgres',
    max: Math.max(1, Number(process.env.PG_POOL_MAX) || 10),
    connectionTimeoutMillis: Number(process.env.PG_CONNECT_TIMEOUT_MS) || 10000
  };

  if (connectionString) {
    delete config.host;
    delete config.port;
    delete config.database;
    delete config.user;
    delete config.password;
    config.connectionString = connectionString;
  }

  if (process.env.PGSSL === 'true' || process.env.PG_SSL === 'true') {
    config.ssl = { rejectUnauthorized: false };
  }

  return config;
}

/** Pool is exported for advanced use (e.g. the data migration script). */
const pool = new Pool(buildConnectionConfig());

/**
 * Translate application SQL to PostgreSQL dialect:
 *   1. Convert SQLite `?` placeholders to PostgreSQL $1..$n parameters.
 *   2. Quote unquoted `AS alias` column aliases ("AS \"fileName\"") so the
 *      returned row keeps the camelCase key the JavaScript code expects
 *      (PostgreSQL folds unquoted identifiers to lowercase).
 */
function translateSql(sql) {
  let index = 0;
  return String(sql)
    .replace(/\?/g, () => `$${++index}`)
    .replace(/\s+as\s+([a-zA-Z_][a-zA-Z0-9_]*)/gi, ' as "$1"');
}

/** Map JS values to values accepted by PostgreSQL. */
function toParam(value) {
  if (value === undefined) return null;
  if (typeof value === 'boolean') return value ? 1 : 0;
  return value;
}

/**
 * Lazy, idempotent schema/seed initialisation.
 * The initializer (server.js's `initializeDatabase`) runs exactly once on the
 * first database access. While it is running, nested db calls are allowed to
 * proceed straight to the pool (guarded by `running`) instead of waiting on a
 * promise that can only resolve after the initializer finishes.
 */
let initializer = null;
let initialized = null;
let running = false;

function ensureReady() {
  if (!initializer || running) return Promise.resolve();
  if (initialized) return initialized;
  running = true;
  initialized = Promise.resolve()
    .then(initializer)
    .then(() => undefined)
    .catch((error) => {
      // Allow a later query to retry if e.g. the database was briefly offline.
      initialized = null;
      throw error;
    })
    .finally(() => {
      running = false;
    });
  return initialized;
}

/** Register the function that creates the schema + seed data. */
function setInitializer(fn) {
  if (typeof fn !== 'function') throw new Error('db.setInitializer expects a function.');
  initializer = fn;
}

async function execute(client, sql, params) {
  const converted = translateSql(sql);
  const values = (params || []).map(toParam);
  return client.query(converted, values);
}

async function all(sql, ...params) {
  await ensureReady();
  const result = await execute(pool, sql, params);
  return result.rows;
}

async function get(sql, ...params) {
  const rows = await all(sql, ...params);
  return rows[0];
}

async function run(sql, ...params) {
  await ensureReady();
  const result = await execute(pool, sql, params);
  return { changes: result.rowCount, lastInsertRowid: null };
}

async function exec(sql, ...params) {
  return run(sql, ...params);
}

/**
 * Run fn(tx) inside a PostgreSQL transaction. `tx` exposes the same
 * get/all/run/exec helpers but bound to the transaction connection, so the
 * whole block commits (or rolls back) atomically.
 */
async function transaction(fn) {
  await ensureReady();
  const client = await pool.connect();
  const tx = {};

  tx.get = async (sql, ...params) => {
    const result = await execute(client, sql, params);
    return result.rows[0];
  };
  tx.all = async (sql, ...params) => {
    const result = await execute(client, sql, params);
    return result.rows;
  };
  tx.run = async (sql, ...params) => {
    const result = await execute(client, sql, params);
    return { changes: result.rowCount, lastInsertRowid: null };
  };
  tx.exec = tx.run;

  try {
    await client.query('BEGIN');
    const result = await fn(tx);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {
      // Connection may have dropped; nothing else we can do here.
    }
    throw error;
  } finally {
    client.release();
  }
}

async function close() {
  await pool.end();
}

module.exports = {
  pool,
  setInitializer,
  initialize: () => ensureReady(),
  get,
  all,
  run,
  exec,
  transaction,
  close,
  translateSql,
  toParam
};