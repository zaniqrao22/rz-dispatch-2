'use strict';

/**
 * One-command developer launcher: starts the embedded PostgreSQL database if
 * it is not already running, initializes the schema, then starts the app.
 *
 * Usage:
 *   npm run dev
 *
 * Production deployments should use `npm start` against an externally managed
 * PostgreSQL instance (see DEPLOYMENT.md).
 */

require('dotenv').config();
const net = require('net');
const path = require('path');
const EmbeddedPostgres = require('embedded-postgres').default;
const { initializeDatabase, app } = require('../server');

function isPortOpen(port) {
  return new Promise((resolve) => {
    const socket = net.connect({ port, host: '127.0.0.1' });
    socket.once('connect', () => { socket.destroy(); resolve(true); });
    socket.once('error', () => resolve(false));
  });
}

async function main() {
  const dbPort = Number(process.env.PGPORT) || 55432;
  const user = process.env.PGUSER || 'postgres';
  const password = process.env.PGPASSWORD || 'postgres';
  const database = process.env.PGDATABASE || 'rz_dispatch';

  if (!(await isPortOpen(dbPort))) {
    console.log(`Embedded PostgreSQL not running on 127.0.0.1:${dbPort}; starting it...`);
    const pg = new EmbeddedPostgres({
      databaseDir: path.join(__dirname, '..', '.pgdata'),
      user,
      password,
      authMethod: 'scram-sha-256',
      port: dbPort,
      persistent: true,
      onLog: () => {}
    });
    await pg.initialise();
    await pg.start();
    try {
      await pg.createDatabase(database);
    } catch (_) {
      // Already exists.
    }
    console.log(`Embedded PostgreSQL started on 127.0.0.1:${dbPort}.`);
  }

  await initializeDatabase();

  const PORT = Number(process.env.PORT) || 8000;
  const HOST = process.env.HOST || '0.0.0.0';
  app.listen(PORT, HOST, () => {
    console.log(`RZ Dispatch SaaS running at http://${HOST}:${PORT}`);
  });
}

main().catch((error) => {
  console.error('Failed to start:', error.message);
  process.exit(1);
});