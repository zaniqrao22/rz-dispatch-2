require('dotenv').config();
const express = require('express');
const fs = require('fs');
const helmet = require('helmet');
const crypto = require('crypto');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');
const Stripe = require('stripe');

const app = express();
const PORT = Number(process.env.PORT) || 8000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.join(__dirname, '.data');
const PUBLIC_URL = process.env.PUBLIC_URL || `http://localhost:${PORT}`;
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? null : 'dev-only-insecure-secret-change-me');
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is required in production. Generate one with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"');
  process.exit(1);
}
if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not set. Using an insecure development secret. Set JWT_SECRET before deploying.');
}
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@rzdispatch.local').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Demo@12345';
const OPERATOR_EMAIL = (process.env.OPERATOR_EMAIL || 'operator@rzdispatch.local').toLowerCase();
const OPERATOR_PASSWORD = process.env.OPERATOR_PASSWORD || 'Operator@12345';
const OPERATOR_DRIVER_ID = process.env.OPERATOR_DRIVER_ID || 'DR-102';
const APP_MODE = process.env.APP_MODE || 'saas';
const REQUIRE_LICENSE = process.env.REQUIRE_LICENSE !== 'false';
const DEMO_LICENSE_KEY = (process.env.DEMO_LICENSE_KEY || process.env.RZ_LICENSE_KEY || '').trim();
const LIFETIME_PRICE_CENTS = Number(process.env.LIFETIME_PRICE_CENTS) || 49900;
const LIFETIME_CURRENCY = process.env.LIFETIME_CURRENCY || 'usd';
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const stripeWebhookSecret = process.env.STRIPE_WEBHOOK_SECRET || '';
if (stripe && !stripeWebhookSecret) {
  console.warn('WARNING: STRIPE_SECRET_KEY is set but STRIPE_WEBHOOK_SECRET is not. License fulfillment via webhook will be unavailable.');
}

const rateBuckets = new Map();
// The PostgreSQL connection pool lives in ./db; schema/seed initialization is
// registered lazily below so it runs on the first database access.
const defaultJobs = [
  { id: 'JO-8421', type: 'PICKUP', priority: 'High priority', from: '1280 Market Street', to: '77 Geary Street', time: 'Today, 10:40 AM', distance: '2.4 mi', price: '$42.80', status: 'queued' },
  { id: 'JO-8418', type: 'DELIVERY', priority: 'Standard', from: '420 Hayes Street', to: '16th & Valencia', time: 'Today, 10:48 AM', distance: '3.1 mi', price: '$38.20', status: 'queued' },
  { id: 'JO-8415', type: 'PICKUP', priority: 'High priority', from: '85 2nd Street', to: 'Mission Bay', time: 'Today, 10:54 AM', distance: '4.8 mi', price: '$51.60', status: 'queued' },
  { id: 'JO-8409', type: 'DELIVERY', priority: 'Standard', from: '601 4th Street', to: 'Pier 39', time: 'Today, 11:02 AM', distance: '5.2 mi', price: '$44.10', status: 'queued' }
];
const defaultDrivers = [
  { id: 'DR-101', name: 'Marco Lee', initials: 'ML', status: 'On route', vehicle: 'Van 12', jobs: 8, rating: '4.9' },
  { id: 'DR-102', name: 'Sarah Kim', initials: 'SK', status: 'Available', vehicle: 'Van 08', jobs: 6, rating: '4.8' },
  { id: 'DR-103', name: 'Daniel Ruiz', initials: 'DR', status: 'On route', vehicle: 'Truck 21', jobs: 11, rating: '4.9' },
  { id: 'DR-104', name: 'Avery Chen', initials: 'AC', status: 'Offline', vehicle: 'Van 04', jobs: 5, rating: '4.7' }
];
const defaultActivity = [
  { initials: 'ML', name: 'Marco Lee', action: 'accepted job JO-8416', detail: 'Pickup at 2100 Franklin St', time: '2 min ago' },
  { initials: 'SK', name: 'Sarah Kim', action: 'arrived at pickup', detail: 'Job JO-8414 · 900 Battery St', time: '7 min ago' },
  { initials: 'DR', name: 'Daniel Ruiz', action: 'completed delivery', detail: 'Job JO-8408 · 1.2 mi trip', time: '12 min ago' }
];
const defaultMessages = [
  { sender: 'Sarah Kim', initials: 'SK', subject: 'Pickup delayed at 420 Hayes', body: 'Traffic is building near the pickup. I can still make the revised ETA if the next load is pushed by ten minutes.', type: 'operations' },
  { sender: 'Marco Lee', initials: 'ML', subject: 'Vehicle inspection complete', body: 'Van 12 passed inspection and is ready for another route.', type: 'fleet' },
  { sender: 'System', initials: 'RZ', subject: 'Route optimization applied', body: 'Your active loads were sequenced using priority and known distance.', type: 'system' }
];
const defaultServices = [
  { key: 'airport-transfer', name: 'Airport transfer', description: 'Flight-aware pickups and drop-offs for SFO, OAK, and SJC.', basePrice: 68, distanceRate: 2.75, hourlyRate: 0, active: 1 },
  { key: 'same-day', name: 'Same-day ride', description: 'Fast local transportation for urgent trips and business needs.', basePrice: 45, distanceRate: 2.25, hourlyRate: 0, active: 1 },
  { key: 'hourly', name: 'Hourly charter', description: 'Flexible multi-stop transport with a dedicated chauffeur.', basePrice: 55, distanceRate: 0, hourlyRate: 55, active: 1 },
  { key: 'charter', name: 'Full charter', description: 'Private group transportation for teams and events.', basePrice: 110, distanceRate: 3.5, hourlyRate: 110, active: 1 }
];
const defaultZones = [
  { key: 'downtown-sf', name: 'Downtown San Francisco', boundary: '37.7749,-122.4194;37.7955,-122.3937', baseSurcharge: 0, distanceSurcharge: 0, active: 1 },
  { key: 'south-bay', name: 'San Mateo & South Bay', boundary: '37.4419,-122.1430;37.6879,-122.4702', baseSurcharge: 8, distanceSurcharge: 0.35, active: 1 },
  { key: 'east-bay', name: 'East Bay', boundary: '37.8044,-122.2712;37.6879,-122.4702', baseSurcharge: 12, distanceSurcharge: 0.5, active: 1 },
  { key: 'north-bay', name: 'North Bay', boundary: '38.1041,-122.5697;37.8272,-122.4796', baseSurcharge: 15, distanceSurcharge: 0.65, active: 1 },
  { key: 'airport-corridors', name: 'Airport corridors', boundary: '37.6213,-122.3790;37.7126,-122.2120', baseSurcharge: 10, distanceSurcharge: 0.25, active: 1 }
];

// Create the schema and seed data on the first database access.
db.setInitializer(() => initializeDatabase());

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:']
    }
  }
}));
app.use(express.json({ limit: '5mb' }));
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), handleStripeWebhook);
app.use('/api/auth', rateLimit({ windowMs: 60 * 1000, max: 20, name: 'auth' }));
app.use('/api/quotes', rateLimit({ windowMs: 60 * 1000, max: 20, name: 'quotes' }));
app.use('/api/bookings', rateLimit({ windowMs: 60 * 1000, max: 20, name: 'bookings' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const origin = req.headers.origin;
  const allowedOrigins = [`http://localhost:${PORT}`, `http://127.0.0.1:${PORT}`, PUBLIC_URL];
  if (!origin || allowedOrigins.includes(origin)) {
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-License-Key, Authorization');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'RZ Dispatch', appMode: APP_MODE, requireLicense: REQUIRE_LICENSE, version: '2.0.0' });
});

app.post('/api/auth/register', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!isEmail(email)) return res.status(400).json({ error: 'A valid email is required.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  const existing = await db.get('SELECT id FROM users WHERE email = ?', email);
  if (existing) return res.status(409).json({ error: 'An account with this email already exists.' });

  const userId = crypto.randomUUID();
  const passwordHash = bcrypt.hashSync(password, 12);
  await db.run('INSERT INTO users (id, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)',
    userId, email, passwordHash, 'owner', new Date().toISOString());

  const token = signToken({ id: userId, email, role: 'owner' });
  res.status(201).json({ token, user: { id: userId, email, role: 'owner', name: emailName(email) } });
});

app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = await db.get('SELECT * FROM users WHERE email = ?', email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const token = signToken({ id: user.id, email: user.email, role: user.role, driverId: user.driver_id });
  res.json({ token, user: { id: user.id, email: user.email, role: user.role, driverId: user.driver_id, name: emailName(user.email) } });
});

app.get('/api/operator/jobs', requireAuth, requireOperator, async (req, res) => {
  const driver = getDrivers().find((item) => item.id === req.user.driverId);
  const jobs = (await getJobs()).filter((job) => job.driver === driver?.name);
  res.json({ operator: { id: req.user.id, email: req.user.email, driverId: req.user.driverId, name: driver?.name || req.user.email }, jobs, updatedAt: new Date().toISOString() });
});

app.get('/api/operator/jobs/:id', requireAuth, requireOperator, async (req, res) => {
  const job = await getOperatorJob(req.user, req.params.id);
  if (!job) return res.status(404).json({ error: 'Assigned job not found.' });
  const proof = await db.all('SELECT id, file_name as fileName, mime_type as mimeType, byte_size as byteSize, created_at as createdAt FROM proof_documents WHERE job_id = ? AND operator_id = ? ORDER BY created_at DESC', job.id, req.user.id);
  res.json({ job, proof });
});

app.patch('/api/operator/jobs/:id/status', requireAuth, requireOperator, async (req, res) => {
  const job = await getOperatorJob(req.user, req.params.id);
  if (!job) return res.status(404).json({ error: 'Assigned job not found.' });
  const nextStatus = String(req.body?.status || '').toLowerCase();
  const allowed = { assigned: ['en_route'], en_route: ['arrived'], arrived: ['picked_up'], picked_up: ['delivered'], delivered: [] };
  if (!allowed[job.status]?.includes(nextStatus)) return res.status(400).json({ error: `Cannot move ${job.id} from ${job.status} to ${nextStatus}.` });
  const storedStatus = nextStatus === 'delivered' ? 'completed' : nextStatus;
  await db.run('UPDATE jobs SET status = ? WHERE id = ?', storedStatus, job.id);
  await activityPush({ initials: 'OP', name: driverDisplayName(req.user), action: `moved ${job.id} to ${nextStatus}`, detail: `${job.from} to ${job.to}`, time: 'just now' });
  res.json({ job: await getOperatorJob(req.user, job.id), message: `${job.id} is now ${nextStatus}` });
});

app.post('/api/operator/jobs/:id/proof', requireAuth, requireOperator, async (req, res) => {
  const job = await getOperatorJob(req.user, req.params.id);
  if (!job) return res.status(404).json({ error: 'Assigned job not found.' });
  const mimeType = String(req.body?.mimeType || '').toLowerCase();
  const fileName = String(req.body?.fileName || 'proof-of-delivery').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120);
  const encoded = String(req.body?.data || '');
  if (!['image/jpeg', 'image/png', 'application/pdf'].includes(mimeType)) return res.status(415).json({ error: 'Only JPG, PNG, or PDF proof documents are accepted.' });
  if (!encoded || encoded.length > 4_200_000) return res.status(413).json({ error: 'Proof document is missing or larger than 3 MB.' });
  let buffer;
  try { buffer = Buffer.from(encoded.replace(/^data:[^;]+;base64,/, ''), 'base64'); } catch (error) { return res.status(400).json({ error: 'Invalid proof document encoding.' }); }
  if (!buffer.length || buffer.length > 3 * 1024 * 1024) return res.status(413).json({ error: 'Proof document is missing or larger than 3 MB.' });
  const extension = mimeType === 'application/pdf' ? 'pdf' : mimeType === 'image/png' ? 'png' : 'jpg';
  const documentId = crypto.randomUUID();
  const relativePath = path.join('proof', `${documentId}.${extension}`);
  const absolutePath = path.join(DATA_DIR, relativePath);
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
  fs.writeFileSync(absolutePath, buffer, { flag: 'wx' });
  await db.run('INSERT INTO proof_documents (id, job_id, operator_id, file_name, mime_type, file_path, byte_size, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', documentId, job.id, req.user.id, fileName, mimeType, relativePath, buffer.length, new Date().toISOString());
  await activityPush({ initials: 'OP', name: driverDisplayName(req.user), action: `uploaded proof for ${job.id}`, detail: fileName, time: 'just now' });
  res.status(201).json({ proof: { id: documentId, jobId: job.id, fileName, mimeType, byteSize: buffer.length }, message: 'Proof of delivery uploaded.' });
});

app.get('/api/operator/proof/:id', requireAuth, requireOperator, async (req, res) => {
  const document = await db.get('SELECT * FROM proof_documents WHERE id = ? AND operator_id = ?', req.params.id, req.user.id);
  if (!document) return res.status(404).json({ error: 'Proof document not found.' });
  const absolutePath = path.join(DATA_DIR, document.file_path);
  if (!fs.existsSync(absolutePath)) return res.status(410).json({ error: 'Proof document is no longer available.' });
  res.type(document.mime_type).sendFile(path.resolve(absolutePath));
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: { ...req.user, name: emailName(req.user.email) } });
});

app.get('/api/account/summary', requireAuth, async (req, res) => {
  res.json(await buildAccountSummary(req.user));
});

app.get('/api/admin/overview', requireAuth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  res.json(await getAdminOverview());
});

app.get('/api/admin/billing', requireAuth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  res.json(await buildBillingSummary());
});

app.post('/api/auth/verify-email', requireAuth, (req, res) => {
  const user = req.user;
  const token = createEmailVerificationToken({ id: user.id, email: user.email });
  res.json({ success: true, token, verified: true, email: user.email });
});

app.get('/api/auth/verify-email/:token', (req, res) => {
  try {
    const payload = verifyEmailToken(req.params.token);
    res.json({ success: true, verified: true, userId: payload.userId, email: payload.email });
  } catch (error) {
    res.status(400).json({ error: 'Verification token is invalid or expired.' });
  }
});

app.get('/api/license/status', async (req, res) => {
  const suppliedKey = getLicenseKeyFromRequest(req);
  const active = await hasValidLicense(req.user || null, suppliedKey);
  res.json({
    active,
    locked: REQUIRE_LICENSE,
    mode: APP_MODE,
    message: active ? 'License active' : 'License required',
    demoKeyConfigured: Boolean(DEMO_LICENSE_KEY)
  });
});

app.post('/api/license/activate', requireAuth, async (req, res) => {
  const submittedKey = String(req.body?.licenseKey || '').trim();
  const email = String(req.body?.email || '').trim();

  if (!submittedKey && !email) {
    return res.status(400).json({ error: 'Provide a license key or email to activate.' });
  }

  if (submittedKey && !validateLicenseKey(submittedKey)) {
    return res.status(400).json({ error: 'This license key is invalid.' });
  }

  const normalizedKey = normalizeLicenseKey(submittedKey || DEMO_LICENSE_KEY);
  if (!normalizedKey) {
    return res.status(402).json({ error: 'No active license found. Start checkout to unlock the app.' });
  }

  const existing = await findLicenseRecord(normalizedKey, req.user.id);
  if (existing) {
    return res.json({ success: true, licenseKey: existing.licenseKey, type: existing.type, status: existing.status });
  }

  if (DEMO_LICENSE_KEY && normalizeLicenseKey(DEMO_LICENSE_KEY) === normalizedKey) {
    const record = await createLicenseRecord({ userId: req.user.id, customerEmail: email || req.user.email, source: 'demo', stripeSessionId: null, licenseKey: normalizedKey });
    return res.json({ success: true, licenseKey: record.licenseKey, type: record.type, status: record.status });
  }

  return res.status(404).json({ error: 'License not found or not active.' });
});

app.use('/api', requireAuth, async (req, res, next) => {
  if (!REQUIRE_LICENSE) return next();
  const publicPaths = ['/customer/order', '/purchase/lifetime', '/purchase/license'];
  const normalizedPath = req.path.replace(/\/+$/, '');
  if (publicPaths.some((p) => normalizedPath === p)) return next();
  const key = getLicenseKeyFromRequest(req);
  if (await hasValidLicense(req.user, key)) return next();
  return res.status(402).json({ error: 'License required', licenseRequired: true, message: 'Activate your RZ Dispatch license to continue.' });
});

app.get('/api/customer/order', async (req, res) => {
  const orderId = String(req.query.orderId || '').trim();
  const email = String(req.query.email || '').trim().toLowerCase();

  if (!orderId || !email) {
    return res.status(400).json({ error: 'Both orderId and email are required.' });
  }

  const result = await lookupCustomerOrder({ orderId, email });
  if (!result) {
    return res.status(404).json({ error: 'No order found for that email and order ID.' });
  }

  res.json(result);
});

app.get('/api/dashboard', requireAuth, async (req, res) => {
  const jobs = await getJobs();
  const assigned = jobs.filter((job) => job.status === 'assigned').length;
  const queued = jobs.filter((job) => job.status === 'queued').length;
  res.json({ metrics: { active: queued + assigned + 20, onRoad: 18 + assigned, available: Math.max(0, 6 - assigned), eta: 18 }, jobs, updatedAt: new Date().toISOString() });
});

app.get('/api/overview', requireAuth, async (req, res) => {
  const jobs = await getJobs();
  const assigned = jobs.filter((job) => job.status === 'assigned').length;
  const queued = jobs.filter((job) => job.status === 'queued').length;
  const drivers = getDrivers();
  const activity = await getActivity();
  res.json({
    metrics: { active: queued + assigned + 20, onRoad: 18 + assigned, available: Math.max(0, 6 - assigned), eta: 18 },
    jobs,
    drivers,
    activity,
    analytics: { completed: 38 + assigned, onTimeRate: 92, utilization: 78, distance: `${(142 + assigned * 2).toFixed(1)} mi` },
    bookings: await getBookingRecords(),
    quotes: await getQuoteRecords(),
    updatedAt: new Date().toISOString()
  });
});

app.get('/api/search', requireAuth, async (req, res) => {
  const query = String(req.query.q || '').trim().toLowerCase();
  if (!query) return res.json({ results: [] });
  const jobs = (await getJobs()).filter((job) => [job.id, job.from, job.to, job.driver, job.status].some((value) => String(value || '').toLowerCase().includes(query))).map((job) => ({ type: 'job', id: job.id, label: `${job.id} · ${job.from} → ${job.to}`, status: job.status }));
  const customers = (await buildCustomerDirectory()).filter((customer) => [customer.name, customer.email, customer.phone].some((value) => String(value || '').toLowerCase().includes(query))).map((customer) => ({ type: 'customer', id: customer.id, label: `${customer.name} · ${customer.email}`, status: `${customer.bookings} bookings` }));
  const services = (await getServiceConfigurations()).filter((service) => [service.key, service.name, service.description].some((value) => String(value || '').toLowerCase().includes(query))).map((service) => ({ type: 'service', id: service.key, label: service.name, status: service.active ? 'Active' : 'Hidden' }));
  res.json({ results: [...jobs, ...customers, ...services].slice(0, 20) });
});

app.get('/api/notifications', requireAuth, async (req, res) => {
  const messages = await db.all('SELECT id, subject, body, type, created_at as createdAt FROM messages WHERE is_read = 0 ORDER BY created_at DESC LIMIT 20');
  res.json({ notifications: messages, unread: messages.length });
});

app.get('/api/activity', requireAuth, async (req, res) => {
  res.json({ activity: await db.all('SELECT initials, name, action, detail, time, created_at as createdAt FROM activity ORDER BY created_at DESC LIMIT 100') });
});

app.get('/api/messages', requireAuth, async (req, res) => {
  const messages = await db.all('SELECT id, sender, initials, subject, body, type, is_read as isRead, created_at as createdAt FROM messages ORDER BY created_at DESC LIMIT 50');
  res.json({ messages, unread: messages.filter((message) => !message.isRead).length });
});

app.post('/api/messages', requireAuth, async (req, res) => {
  const subject = String(req.body?.subject || '').trim();
  const body = String(req.body?.body || '').trim();
  const type = String(req.body?.type || 'operations').trim().toLowerCase();
  if (!isText(subject) || !isText(body)) return res.status(400).json({ error: 'Subject and message are required.' });
  const message = { id: crypto.randomUUID(), sender: req.user.email, initials: req.user.email.slice(0, 2).toUpperCase(), subject, body, type, isRead: 1, createdAt: new Date().toISOString() };
  await db.run('INSERT INTO messages (id, sender, initials, subject, body, type, is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', message.id, message.sender, message.initials, message.subject, message.body, message.type, message.isRead, message.createdAt);
  res.status(201).json({ message });
});

app.patch('/api/messages/:id/read', requireAuth, async (req, res) => {
  const result = await db.run('UPDATE messages SET is_read = 1 WHERE id = ?', req.params.id);
  if (!result.changes) return res.status(404).json({ error: 'Message not found' });
  res.json({ success: true, id: req.params.id });
});

app.get('/api/services', requireAuth, async (req, res) => {
  res.json({ services: await getServiceConfigurations() });
});

app.post('/api/services', requireStaff, async (req, res) => {
  const service = normalizeServiceInput(req.body || {});
  if (!service.key || !service.name || !service.description) return res.status(400).json({ error: 'Key, name, and description are required.' });
  if (await db.get('SELECT key FROM services WHERE key = ?', service.key)) return res.status(409).json({ error: 'A service with this key already exists.' });
  await db.run('INSERT INTO services (key, name, description, base_price, distance_rate, hourly_rate, active, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', service.key, service.name, service.description, service.basePrice, service.distanceRate, service.hourlyRate, service.active, new Date().toISOString());
  res.status(201).json({ service: (await getServiceConfigurations()).find((item) => item.key === service.key) });
});

app.patch('/api/services/:key', requireStaff, async (req, res) => {
  const current = await db.get('SELECT key FROM services WHERE key = ?', req.params.key);
  if (!current) return res.status(404).json({ error: 'Service not found.' });
  const service = normalizeServiceInput(req.body || {}, req.params.key);
  if (!service.name || !service.description) return res.status(400).json({ error: 'Name and description are required.' });
  await db.run('UPDATE services SET name = ?, description = ?, base_price = ?, distance_rate = ?, hourly_rate = ?, active = ?, updated_at = ? WHERE key = ?', service.name, service.description, service.basePrice, service.distanceRate, service.hourlyRate, service.active, new Date().toISOString(), req.params.key);
  res.json({ service: (await getServiceConfigurations()).find((item) => item.key === req.params.key) });
});

app.delete('/api/services/:key', requireStaff, async (req, res) => {
  const result = await db.run('DELETE FROM services WHERE key = ?', req.params.key);
  if (!result.changes) return res.status(404).json({ error: 'Service not found.' });
  res.json({ success: true, key: req.params.key });
});

app.get('/api/coverage/zones', requireAuth, async (req, res) => {
  res.json({ zones: await getZoneConfigurations(), updatedAt: new Date().toISOString() });
});

app.post('/api/coverage/zones', requireStaff, async (req, res) => {
  const zone = normalizeZoneInput(req.body || {});
  if (!zone.key || !zone.name || !zone.boundary) return res.status(400).json({ error: 'Key, region name, and boundary are required.' });
  if (await db.get('SELECT key FROM service_zones WHERE key = ?', zone.key)) return res.status(409).json({ error: 'A zone with this key already exists.' });
  await db.run('INSERT INTO service_zones (key, name, boundary, base_surcharge, distance_surcharge, active, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)', zone.key, zone.name, zone.boundary, zone.baseSurcharge, zone.distanceSurcharge, zone.active, new Date().toISOString());
  res.status(201).json({ zone: (await getZoneConfigurations()).find((item) => item.key === zone.key) });
});

app.patch('/api/coverage/zones/:key', requireStaff, async (req, res) => {
  if (!await db.get('SELECT key FROM service_zones WHERE key = ?', req.params.key)) return res.status(404).json({ error: 'Zone not found.' });
  const zone = normalizeZoneInput(req.body || {}, req.params.key);
  if (!zone.name || !zone.boundary) return res.status(400).json({ error: 'Region name and boundary are required.' });
  await db.run('UPDATE service_zones SET name = ?, boundary = ?, base_surcharge = ?, distance_surcharge = ?, active = ?, updated_at = ? WHERE key = ?', zone.name, zone.boundary, zone.baseSurcharge, zone.distanceSurcharge, zone.active, new Date().toISOString(), req.params.key);
  res.json({ zone: (await getZoneConfigurations()).find((item) => item.key === req.params.key) });
});

app.delete('/api/coverage/zones/:key', requireStaff, async (req, res) => {
  const result = await db.run('DELETE FROM service_zones WHERE key = ?', req.params.key);
  if (!result.changes) return res.status(404).json({ error: 'Zone not found.' });
  res.json({ success: true, key: req.params.key });
});

app.get('/api/schedule', requireAuth, async (req, res) => {
  const date = String(req.query.date || 'today').trim().toLowerCase();
  const jobs = await getJobs();
  const columns = {
    queued: jobs.filter((job) => job.status === 'queued'),
    assigned: jobs.filter((job) => job.status === 'assigned'),
    completed: jobs.filter((job) => job.status === 'completed')
  };
  res.json({ date, columns, total: jobs.length, updatedAt: new Date().toISOString() });
});

app.get('/api/jobs/:id', requireAuth, async (req, res) => {
  const job = (await getJobs()).find((item) => item.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({ job, activity: (await getActivity()).filter((item) => item.detail.includes(job.id) || item.detail.includes(job.from) || item.detail.includes(job.to)).slice(0, 5) });
});

app.post('/api/quotes/estimate', requireAuth, async (req, res) => {
  const estimate = await calculateQuoteEstimate(req.body || {});
  res.json({ estimate, ok: true });
});

app.get('/api/quotes', requireAuth, async (req, res) => {
  res.json({ quotes: await getQuoteRecords() });
});

app.post('/api/quotes', requireAuth, async (req, res) => {
  const normalized = normalizeQuoteInput(req.body || {});
  const estimate = await calculateQuoteEstimate(normalized);
  const quote = await createQuoteRecord({ ...normalized, quoteTotal: estimate.total, status: 'pending' });
  res.status(201).json({ quote, estimate });
});

app.get('/api/bookings', requireAuth, async (req, res) => {
  res.json({ bookings: await getBookingRecords() });
});

app.get('/api/crm/customers', requireAuth, async (req, res) => {
  const customers = await buildCustomerDirectory();
  res.json({ customers, total: customers.length, updatedAt: new Date().toISOString() });
});

app.post('/api/bookings', requireAuth, async (req, res) => {
  const normalized = normalizeQuoteInput(req.body || {});
  const estimate = await calculateQuoteEstimate(normalized);
  const quote = await createQuoteRecord({ ...normalized, quoteTotal: estimate.total, status: 'accepted' });
  const booking = await createBookingRecord({ ...quote, status: 'booked', quoteTotal: estimate.total });
  res.status(201).json({ quote, booking, estimate });
});

app.post('/api/purchase/lifetime', requireAuth, async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Payments are not configured' });
  const email = String(req.body?.email || req.user.email || '').trim();
  if (!email || !isEmail(email)) return res.status(400).json({ error: 'A valid email is required' });

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: LIFETIME_CURRENCY,
          product_data: { name: 'RZ Dispatch Lifetime License', description: 'Permanent self-hosted use. No recurring subscription.' },
          unit_amount: LIFETIME_PRICE_CENTS
        },
        quantity: 1
      }],
      customer_email: email,
      metadata: { product: 'rz-dispatch', licenseType: 'lifetime', userId: req.user.id },
      success_url: `${PUBLIC_URL}/?purchase=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${PUBLIC_URL}/?purchase=cancelled`
    });
    res.json({ checkoutUrl: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Could not create lifetime checkout session:', error.message);
    res.status(502).json({ error: 'Could not start checkout' });
  }
});

app.get('/api/purchase/license', requireAuth, async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Payments are not configured' });
  const sessionId = String(req.query.session_id || '');
  if (!sessionId || !sessionId.startsWith('cs_')) return res.status(400).json({ error: 'A valid checkout session is required' });

  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    const isLifetimePurchase = session.metadata?.product === 'rz-dispatch' && session.metadata?.licenseType === 'lifetime';
    if (!isLifetimePurchase || session.payment_status !== 'paid') return res.status(402).json({ error: 'Payment has not been completed' });
    const license = await fulfillLifetimePurchase({ ...session, userId: req.user.id });
    res.json({ licenseKey: license.licenseKey, type: license.type, status: license.status });
  } catch (error) {
    res.status(404).json({ error: 'Purchase session not found' });
  }
});

app.post('/api/jobs', requireAuth, async (req, res) => {
  const { type, from, to } = req.body || {};
  if (!['pickup', 'delivery'].includes(String(type).toLowerCase()) || !isText(from) || !isText(to)) {
    return res.status(400).json({ error: 'type must be pickup or delivery; from and to are required' });
  }

  const jobs = await getJobs();
  const nextNumber = jobs.length ? Math.max(...jobs.map((job) => Number(job.id.slice(3)))) + 1 : 9000;
  const job = {
    id: `JO-${nextNumber}`,
    type: String(type).toUpperCase(),
    priority: 'Standard',
    from: from.trim(),
    to: to.trim(),
    time: 'Today, 11:20 AM',
    distance: 'Pending',
    price: 'Pending',
    status: 'queued'
  };
  await db.run('INSERT INTO jobs (id, type, priority, from_address, to_address, time, distance, price, status, driver, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', job.id, job.type, job.priority, job.from, job.to, job.time, job.distance, job.price, job.status, null, new Date().toISOString());
  res.status(201).json({ job });
});

app.post('/api/jobs/:id/assign', requireAuth, async (req, res) => {
  const jobs = await getJobs();
  const job = jobs.find((item) => item.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.status === 'assigned') return res.json({ job, message: `${job.id} is already assigned to ${job.driver}` });

  const driver = getDrivers().find((item) => item.status === 'Available');
  if (!driver) return res.status(409).json({ error: 'No available drivers' });

  await db.run('UPDATE jobs SET status = ?, driver = ? WHERE id = ?', 'assigned', driver.name, job.id);
  await activityPush({ initials: 'RZ', name: staffDisplayName(req.user), action: `assigned ${job.id}`, detail: `${job.from} to ${job.to}`, time: 'just now' });
  res.json({ job: { ...job, status: 'assigned', driver: driver.name }, message: `${job.id} assigned to ${driver.name}` });
});

app.patch('/api/jobs/:id', requireAuth, async (req, res) => {
  const current = (await getJobs()).find((item) => item.id === req.params.id);
  if (!current) return res.status(404).json({ error: 'Job not found' });
  const body = req.body || {};
  const type = body.type === undefined ? current.type : String(body.type).toUpperCase();
  const from = body.from === undefined ? current.from : String(body.from).trim();
  const to = body.to === undefined ? current.to : String(body.to).trim();
  const priority = body.priority === undefined ? current.priority : String(body.priority).trim();
  const time = body.time === undefined ? current.time : String(body.time).trim();
  const status = body.status === undefined ? current.status : String(body.status).toLowerCase();
  if (!['PICKUP', 'DELIVERY'].includes(type) || !isText(from) || !isText(to) || !isText(priority) || !isText(time)) {
    return res.status(400).json({ error: 'type, route, priority, and schedule are required' });
  }
  if (!['queued', 'assigned', 'completed', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Invalid job status' });
  }
  await db.run('UPDATE jobs SET type = ?, priority = ?, from_address = ?, to_address = ?, time = ?, status = ? WHERE id = ?',
    type, priority, from, to, time, status, current.id);
  await activityPush({ initials: 'RZ', name: staffDisplayName(req.user), action: `updated ${current.id}`, detail: `${from} to ${to}`, time: 'just now' });
  res.json({ job: (await getJobs()).find((item) => item.id === current.id), message: `${current.id} updated` });
});

app.delete('/api/jobs/:id', requireAuth, async (req, res) => {
  const current = (await getJobs()).find((item) => item.id === req.params.id);
  if (!current) return res.status(404).json({ error: 'Job not found' });
  const proofs = await db.all('SELECT file_path as filePath FROM proof_documents WHERE job_id = ?', current.id);
  proofs.forEach((proof) => {
    const proofPath = path.join(DATA_DIR, proof.filePath);
    if (fs.existsSync(proofPath)) fs.unlinkSync(proofPath);
  });
  await db.run('DELETE FROM proof_documents WHERE job_id = ?', current.id);
  await db.run('DELETE FROM jobs WHERE id = ?', current.id);
  await activityPush({ initials: 'RZ', name: staffDisplayName(req.user), action: `removed ${current.id}`, detail: `${current.from} to ${current.to}`, time: 'just now' });
  res.json({ success: true, id: current.id, message: `${current.id} removed` });
});

app.get('/api/optimization/preview', requireAuth, async (req, res) => {
  const optimized = optimizeDispatchRoute(await getJobs());
  res.json({ jobs: optimized, count: optimized.length, strategy: 'Priority first, then known distance, then job ID.' });
});

app.post('/api/optimization/apply', requireAuth, async (req, res) => {
  const optimized = optimizeDispatchRoute(await getJobs());
  await db.transaction(async (tx) => {
    await tx.run('UPDATE jobs SET route_order = NULL WHERE status NOT IN (?, ?)', 'queued', 'assigned');
    for (const job of optimized) {
      await tx.run('UPDATE jobs SET route_order = ? WHERE id = ?', job.routeOrder, job.id);
    }
  });
  if (optimized.length) await activityPush({ initials: 'RZ', name: staffDisplayName(req.user), action: 'optimized dispatch route', detail: `${optimized.length} active loads sequenced`, time: 'just now' });
  res.json({ success: true, jobs: optimized, count: optimized.length, message: optimized.length ? `Route optimized for ${optimized.length} active loads` : 'No active loads to optimize' });
});

app.use(express.static(path.join(__dirname)));
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found' }));

if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log(`RZ Dispatch SaaS running at http://${HOST}:${PORT}`);
  });
}

module.exports = {
  app,
  initializeDatabase,
  signToken,
  generateLicenseKey,
  validateLicenseKey,
  normalizeLicenseKey,
  createLicenseRecord,
  findLicenseRecord,
  hasValidLicense,
  getLicenseKeyFromRequest,
  isEmail,
  isText,
  requireAuth,
  requireActiveLicense,
  getJobs,
  optimizeDispatchRoute,
  getDrivers,
  getActivity,
  getServiceConfigurations,
  normalizeServiceInput,
  getZoneConfigurations,
  normalizeZoneInput,
  calculateQuoteEstimate,
  createQuoteRecord,
  getQuoteRecords,
  createBookingRecord,
  getBookingRecords,
  buildCustomerDirectory,
  lookupCustomerOrder,
  buildAccountSummary,
  getAdminOverview,
  buildBillingSummary,
  createEmailVerificationToken,
  verifyEmailToken
};

async function initializeDatabase() {
  // Schema. Each statement runs separately: PostgreSQL rejects multiple
  // commands in one prepared statement. `active` / `is_read` stay SMALLINT
  // flags (0/1) so the existing `active = 1` / `is_read = 0` queries keep
  // working exactly as they did on SQLite.
  const statements = [
    `CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      driver_id TEXT,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      priority TEXT NOT NULL,
      from_address TEXT NOT NULL,
      to_address TEXT NOT NULL,
      time TEXT NOT NULL,
      distance TEXT NOT NULL,
      price TEXT NOT NULL,
      status TEXT NOT NULL,
      driver TEXT,
      route_order INTEGER,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS licenses (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      license_key TEXT UNIQUE NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      stripe_session_id TEXT,
      customer_email TEXT,
      source TEXT NOT NULL,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS activity (
      id TEXT PRIMARY KEY,
      initials TEXT NOT NULL,
      name TEXT NOT NULL,
      action TEXT NOT NULL,
      detail TEXT NOT NULL,
      time TEXT NOT NULL,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      sender TEXT NOT NULL,
      initials TEXT NOT NULL,
      subject TEXT NOT NULL,
      body TEXT NOT NULL,
      type TEXT NOT NULL,
      is_read SMALLINT NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS services (
      key TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      base_price DOUBLE PRECISION NOT NULL,
      distance_rate DOUBLE PRECISION NOT NULL,
      hourly_rate DOUBLE PRECISION NOT NULL,
      active SMALLINT NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS service_zones (
      key TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      boundary TEXT NOT NULL,
      base_surcharge DOUBLE PRECISION NOT NULL,
      distance_surcharge DOUBLE PRECISION NOT NULL,
      active SMALLINT NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY,
      customer_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      service_type TEXT NOT NULL,
      pickup_address TEXT NOT NULL,
      dropoff_address TEXT NOT NULL,
      service_date TEXT NOT NULL,
      vehicle_type TEXT NOT NULL,
      miles DOUBLE PRECISION NOT NULL,
      passengers INTEGER NOT NULL,
      hours INTEGER NOT NULL,
      notes TEXT,
      quote_total DOUBLE PRECISION NOT NULL,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      quote_id TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      service_type TEXT NOT NULL,
      pickup_address TEXT NOT NULL,
      dropoff_address TEXT NOT NULL,
      service_date TEXT NOT NULL,
      vehicle_type TEXT NOT NULL,
      miles DOUBLE PRECISION NOT NULL,
      passengers INTEGER NOT NULL,
      hours INTEGER NOT NULL,
      notes TEXT,
      quote_total DOUBLE PRECISION NOT NULL,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS proof_documents (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      operator_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_path TEXT NOT NULL,
      byte_size INTEGER NOT NULL,
      created_at TEXT NOT NULL
    )`,
    // Legacy migrations (already present in the CREATE TABLE statements above
    // for fresh installs, but kept idempotent for pre-existing databases).
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS driver_id TEXT`,
    `ALTER TABLE jobs ADD COLUMN IF NOT EXISTS route_order INTEGER`
  ];

  for (const statement of statements) {
    await db.exec(statement);
  }

  const adminExisting = await db.get('SELECT id FROM users WHERE email = ?', ADMIN_EMAIL);
  if (!adminExisting) {
    await db.run('INSERT INTO users (id, email, password_hash, role, driver_id, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      crypto.randomUUID(), ADMIN_EMAIL, bcrypt.hashSync(ADMIN_PASSWORD, 12), 'admin', null, new Date().toISOString());
  }

  const operatorExisting = await db.get('SELECT id, driver_id as driverId FROM users WHERE email = ?', OPERATOR_EMAIL);
  if (!operatorExisting) {
    await db.run('INSERT INTO users (id, email, password_hash, role, driver_id, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      crypto.randomUUID(), OPERATOR_EMAIL, bcrypt.hashSync(OPERATOR_PASSWORD, 12), 'operator', OPERATOR_DRIVER_ID, new Date().toISOString());
  } else if (!operatorExisting.driverId) {
    // Backfill: an operator account created before the driver_id column existed would
    // otherwise fail the requireOperator guard with "Operator access required."
    await db.run('UPDATE users SET driver_id = ? WHERE id = ?', OPERATOR_DRIVER_ID, operatorExisting.id);
  }

  const jobsCount = Number((await db.get('SELECT COUNT(*) as count FROM jobs'))?.count || 0);
  if (jobsCount === 0) {
    for (const job of defaultJobs) {
      await db.run('INSERT INTO jobs (id, type, priority, from_address, to_address, time, distance, price, status, driver, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        job.id, job.type, job.priority, job.from, job.to, job.time, job.distance, job.price, job.status, null, new Date().toISOString());
    }
  }

  const activityCount = Number((await db.get('SELECT COUNT(*) as count FROM activity'))?.count || 0);
  if (activityCount === 0) {
    for (const item of defaultActivity) {
      await db.run('INSERT INTO activity (id, initials, name, action, detail, time, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        crypto.randomUUID(), item.initials, item.name, item.action, item.detail, item.time, new Date().toISOString());
    }
  }

  const messageCount = Number((await db.get('SELECT COUNT(*) as count FROM messages'))?.count || 0);
  if (messageCount === 0) {
    for (let index = 0; index < defaultMessages.length; index++) {
      const message = defaultMessages[index];
      await db.run('INSERT INTO messages (id, sender, initials, subject, body, type, is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        crypto.randomUUID(), message.sender, message.initials, message.subject, message.body, message.type, index === 2 ? 1 : 0, new Date(Date.now() - index * 600000).toISOString());
    }
  }

  const serviceCount = Number((await db.get('SELECT COUNT(*) as count FROM services'))?.count || 0);
  if (serviceCount === 0) {
    for (const service of defaultServices) {
      await db.run('INSERT INTO services (key, name, description, base_price, distance_rate, hourly_rate, active, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        service.key, service.name, service.description, service.basePrice, service.distanceRate, service.hourlyRate, service.active, new Date().toISOString());
    }
  }

  const zoneCount = Number((await db.get('SELECT COUNT(*) as count FROM service_zones'))?.count || 0);
  if (zoneCount === 0) {
    for (const zone of defaultZones) {
      await db.run('INSERT INTO service_zones (key, name, boundary, base_surcharge, distance_surcharge, active, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        zone.key, zone.name, zone.boundary, zone.baseSurcharge, zone.distanceSurcharge, zone.active, new Date().toISOString());
    }
  }
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Authentication required.' });

  try {
    const token = header.slice(7);
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await db.get('SELECT id, email, role, driver_id as driverId FROM users WHERE id = ?', decoded.id || decoded.sub);
    if (!user) return res.status(401).json({ error: 'Invalid session.' });
    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Session expired or invalid.' });
  }
}

function requireStaff(req, res, next) {
  if (!req.user || !['admin', 'owner'].includes(req.user.role)) return res.status(403).json({ error: 'Staff access required.' });
  next();
}

function requireOperator(req, res, next) {
  if (!req.user || req.user.role !== 'operator' || !req.user.driverId) return res.status(403).json({ error: 'Operator access required.' });
  next();
}

function driverDisplayName(user) {
  return getDrivers().find((driver) => driver.id === user.driverId)?.name || user.email;
}

function staffDisplayName(user) {
  return String(user.email || 'Dispatcher').split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) || 'Dispatcher';
}

async function getOperatorJob(user, id) {
  const driverName = driverDisplayName(user);
  return (await getJobs()).find((job) => job.id === id && job.driver === driverName);
}

async function requireActiveLicense(req, res, next) {
  if (!REQUIRE_LICENSE) return next();
  if (await hasValidLicense(req.user)) return next();
  return res.status(402).json({ error: 'License required', licenseRequired: true, message: 'Activate your RZ Dispatch license to continue.' });
}

async function getJobs() {
  const rows = await db.all('SELECT id, type, priority, from_address, to_address, time, distance, price, status, driver, route_order FROM jobs ORDER BY CASE WHEN route_order IS NULL THEN 1 ELSE 0 END, route_order ASC, created_at DESC');
  return rows.map((job) => ({
    ...job,
    from: job.from_address,
    to: job.to_address,
    routeOrder: job.route_order
  }));
}

function optimizeDispatchRoute(jobs) {
  const priorityRank = { Urgent: 0, 'High priority': 1, Standard: 2 };
  const distanceValue = (job) => {
    const value = Number.parseFloat(String(job.distance).replace(/[^0-9.]/g, ''));
    return Number.isFinite(value) ? value : Number.MAX_SAFE_INTEGER;
  };
  return [...jobs]
    .filter((job) => ['queued', 'assigned'].includes(job.status))
    .sort((a, b) => (priorityRank[a.priority] ?? 3) - (priorityRank[b.priority] ?? 3) || distanceValue(a) - distanceValue(b) || a.id.localeCompare(b.id))
    .map((job, index) => ({ ...job, routeOrder: index + 1, optimizationReason: `${job.priority}; ${distanceValue(job) === Number.MAX_SAFE_INTEGER ? 'distance pending' : `${distanceValue(job)} mi`}` }));
}

function getDrivers() {
  return defaultDrivers;
}

async function getActivity() {
  return db.all('SELECT initials, name, action, detail, time FROM activity ORDER BY created_at DESC LIMIT 10');
}

async function getServiceConfigurations() {
  return (await db.all('SELECT key, name, description, base_price as basePrice, distance_rate as distanceRate, hourly_rate as hourlyRate, active, updated_at as updatedAt FROM services ORDER BY name ASC')).map((service) => ({ ...service, basePrice: Number(service.basePrice), distanceRate: Number(service.distanceRate), hourlyRate: Number(service.hourlyRate), active: Boolean(service.active) }));
}

function normalizeServiceInput(data = {}, fallbackKey = '') {
  const key = String(data.key || fallbackKey).trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
  return { key, name: String(data.name || '').trim(), description: String(data.description || '').trim(), basePrice: Math.max(0, Number(data.basePrice) || 0), distanceRate: Math.max(0, Number(data.distanceRate) || 0), hourlyRate: Math.max(0, Number(data.hourlyRate) || 0), active: data.active === undefined ? 1 : (data.active === true || data.active === 'true' || data.active === 'on' || data.active === 1 ? 1 : 0) };
}

async function getZoneConfigurations() {
  return (await db.all('SELECT key, name, boundary, base_surcharge as baseSurcharge, distance_surcharge as distanceSurcharge, active, updated_at as updatedAt FROM service_zones ORDER BY name ASC')).map((zone) => ({ ...zone, baseSurcharge: Number(zone.baseSurcharge), distanceSurcharge: Number(zone.distanceSurcharge), active: Boolean(zone.active) }));
}

function normalizeZoneInput(data = {}, fallbackKey = '') {
  const key = String(data.key || fallbackKey).trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
  return { key, name: String(data.name || '').trim(), boundary: String(data.boundary || '').trim(), baseSurcharge: Math.max(0, Number(data.baseSurcharge) || 0), distanceSurcharge: Math.max(0, Number(data.distanceSurcharge) || 0), active: data.active === undefined ? 1 : (data.active === true || data.active === 'true' || data.active === 'on' || data.active === 1 ? 1 : 0) };
}

async function calculateQuoteEstimate({ serviceType, vehicleType, miles, passengers, hours = 1 } = {}) {
  const service = String(serviceType || 'same-day').toLowerCase();
  const vehicle = String(vehicleType || 'car').toLowerCase();
  const distance = Number(miles) || 0;
  const seats = Math.max(1, Number(passengers) || 1);
  const duration = Math.max(1, Number(hours) || 1);

  const baseByService = {
    'same-day': 45,
    'airport-transfer': 68,
    hourly: 55,
    charter: 110
  };
  const vehicleMultiplier = {
    car: 1,
    suv: 1.35,
    van: 1.7,
    luxury: 2.1
  };

  const configuredService = await db.get('SELECT base_price, distance_rate FROM services WHERE key = ? AND active = 1', service);
  const base = Number(configuredService?.base_price ?? baseByService[service] ?? 52);
  const serviceDistanceRate = Number(configuredService?.distance_rate ?? 1.35);
  const distanceRate = distance * serviceDistanceRate * (vehicle === 'van' ? 1.6 : vehicle === 'suv' ? 1.35 : vehicle === 'luxury' ? 1.85 : 1);
  const passengerSurcharge = Math.max(0, seats - 1) * 12;
  const durationMultiplier = Math.max(1, duration / 2);
  const subtotal = (base + distanceRate + passengerSurcharge) * durationMultiplier * (vehicleMultiplier[vehicle] || 1);
  const serviceFee = subtotal * 0.12;
  const tax = (subtotal + serviceFee) * 0.08;
  const total = subtotal + serviceFee + tax;

  return {
    status: 'ready',
    currency: 'USD',
    serviceType: service,
    vehicleType: vehicle,
    miles: Number(distance.toFixed(2)),
    passengers: seats,
    hours: duration,
    breakdown: {
      base: Number(base.toFixed(2)),
      distanceRate: Number(distanceRate.toFixed(2)),
      passengerSurcharge: Number(passengerSurcharge.toFixed(2)),
      serviceFee: Number(serviceFee.toFixed(2)),
      tax: Number(tax.toFixed(2))
    },
    subtotal: Number(subtotal.toFixed(2)),
    total: Number(total.toFixed(2))
  };
}

function normalizeQuoteInput(data = {}) {
  const payload = data || {};
  return {
    customerName: String(payload.customerName || '').trim(),
    email: String(payload.email || '').trim(),
    phone: String(payload.phone || '').trim(),
    serviceType: String(payload.serviceType || 'same-day').trim(),
    pickupAddress: String(payload.pickupAddress || '').trim(),
    dropoffAddress: String(payload.dropoffAddress || '').trim(),
    serviceDate: String(payload.serviceDate || new Date(Date.now() + 86400000).toISOString().slice(0, 10)),
    vehicleType: String(payload.vehicleType || 'car').trim(),
    miles: Number(payload.miles || 0),
    passengers: Math.max(1, Number(payload.passengers || 1)),
    hours: Math.max(1, Number(payload.hours || 1)),
    notes: String(payload.notes || '').trim()
  };
}

async function createQuoteRecord({ customerName, email, phone, serviceType, pickupAddress, dropoffAddress, serviceDate, vehicleType, miles, passengers, hours, notes, quoteTotal, status = 'pending' } = {}) {
  const record = {
    id: `Q-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
    customerName: String(customerName || '').trim(),
    email: String(email || '').trim(),
    phone: String(phone || '').trim(),
    serviceType: String(serviceType || 'same-day').trim(),
    pickupAddress: String(pickupAddress || '').trim(),
    dropoffAddress: String(dropoffAddress || '').trim(),
    serviceDate: String(serviceDate || new Date().toISOString().slice(0, 10)),
    vehicleType: String(vehicleType || 'car').trim(),
    miles: Number(miles) || 0,
    passengers: Math.max(1, Number(passengers) || 1),
    hours: Math.max(1, Number(hours) || 1),
    notes: String(notes || '').trim(),
    quoteTotal: Number(quoteTotal) || 0,
    status,
    createdAt: new Date().toISOString()
  };

  await db.run('INSERT INTO quotes (id, customer_name, email, phone, service_type, pickup_address, dropoff_address, service_date, vehicle_type, miles, passengers, hours, notes, quote_total, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    record.id, record.customerName, record.email, record.phone, record.serviceType, record.pickupAddress, record.dropoffAddress, record.serviceDate, record.vehicleType, record.miles, record.passengers, record.hours, record.notes, record.quoteTotal, record.status, record.createdAt);

  return record;
}

async function getQuoteRecords() {
  return (await db.all('SELECT * FROM quotes ORDER BY created_at DESC')).map((quote) => ({
    id: quote.id,
    customerName: quote.customer_name,
    email: quote.email,
    phone: quote.phone,
    serviceType: quote.service_type,
    pickupAddress: quote.pickup_address,
    dropoffAddress: quote.dropoff_address,
    serviceDate: quote.service_date,
    vehicleType: quote.vehicle_type,
    miles: quote.miles,
    passengers: quote.passengers,
    hours: quote.hours,
    notes: quote.notes,
    quoteTotal: Number(quote.quote_total),
    status: quote.status,
    createdAt: quote.created_at
  }));
}

async function createBookingRecord({ id, quoteId, customerName, email, phone, serviceType, pickupAddress, dropoffAddress, serviceDate, vehicleType, miles, passengers, hours, notes, quoteTotal, status = 'booked' } = {}) {
  const record = {
    id: `BK-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
    quoteId: quoteId || id || null,
    customerName: String(customerName || '').trim(),
    email: String(email || '').trim(),
    phone: String(phone || '').trim(),
    serviceType: String(serviceType || 'same-day').trim(),
    pickupAddress: String(pickupAddress || '').trim(),
    dropoffAddress: String(dropoffAddress || '').trim(),
    serviceDate: String(serviceDate || new Date().toISOString().slice(0, 10)),
    vehicleType: String(vehicleType || 'car').trim(),
    miles: Number(miles) || 0,
    passengers: Math.max(1, Number(passengers) || 1),
    hours: Math.max(1, Number(hours) || 1),
    notes: String(notes || '').trim(),
    quoteTotal: Number(quoteTotal) || 0,
    status,
    createdAt: new Date().toISOString()
  };

  await db.run('INSERT INTO bookings (id, quote_id, customer_name, email, phone, service_type, pickup_address, dropoff_address, service_date, vehicle_type, miles, passengers, hours, notes, quote_total, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    record.id, record.quoteId, record.customerName, record.email, record.phone, record.serviceType, record.pickupAddress, record.dropoffAddress, record.serviceDate, record.vehicleType, record.miles, record.passengers, record.hours, record.notes, record.quoteTotal, record.status, record.createdAt);

  return record;
}

async function getBookingRecords() {
  return (await db.all('SELECT * FROM bookings ORDER BY created_at DESC')).map((booking) => ({
    id: booking.id,
    quoteId: booking.quote_id,
    customerName: booking.customer_name,
    email: booking.email,
    phone: booking.phone,
    serviceType: booking.service_type,
    pickupAddress: booking.pickup_address,
    dropoffAddress: booking.dropoff_address,
    serviceDate: booking.service_date,
    vehicleType: booking.vehicle_type,
    miles: booking.miles,
    passengers: booking.passengers,
    hours: booking.hours,
    notes: booking.notes,
    quoteTotal: Number(booking.quote_total),
    status: booking.status,
    createdAt: booking.created_at
  }));
}

async function buildCustomerDirectory() {
  const quotes = await getQuoteRecords();
  const bookings = await getBookingRecords();
  const byEmail = new Map();
  const addCustomerRecord = (record, kind) => {
    const email = record.email.toLowerCase();
    if (!email) return;
    if (!byEmail.has(email)) {
      byEmail.set(email, {
        id: `CUS-${crypto.createHash('sha1').update(email).digest('hex').slice(0, 8).toUpperCase()}`,
        name: record.customerName,
        email: record.email,
        phone: record.phone,
        totalSpend: 0,
        bookings: 0,
        quotes: 0,
        lastContact: record.createdAt,
        history: []
      });
    }
    const customer = byEmail.get(email);
    customer.name = record.customerName || customer.name;
    customer.phone = record.phone || customer.phone;
    customer.lastContact = new Date(record.createdAt) > new Date(customer.lastContact) ? record.createdAt : customer.lastContact;
    customer.history.push({ id: record.id, kind, status: record.status, serviceType: record.serviceType, date: record.serviceDate, route: `${record.pickupAddress} → ${record.dropoffAddress}`, total: record.quoteTotal, createdAt: record.createdAt });
    if (kind === 'booking') {
      customer.bookings += 1;
      customer.totalSpend += record.quoteTotal;
    } else {
      customer.quotes += 1;
    }
  };
  quotes.forEach((quote) => addCustomerRecord(quote, 'quote'));
  bookings.forEach((booking) => addCustomerRecord(booking, 'booking'));
  return [...byEmail.values()].map((customer) => ({ ...customer, totalSpend: Number(customer.totalSpend.toFixed(2)), history: customer.history.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) })).sort((a, b) => new Date(b.lastContact) - new Date(a.lastContact));
}

async function lookupCustomerOrder({ orderId, email } = {}) {
  const normalizedId = String(orderId || '').trim();
  const normalizedEmail = String(email || '').trim().toLowerCase();
  if (!normalizedId || !normalizedEmail) return null;

  const quote = await db.get('SELECT * FROM quotes WHERE id = ? AND LOWER(email) = ?', normalizedId, normalizedEmail);
  if (quote) {
    return {
      kind: 'quote',
      id: quote.id,
      email: quote.email,
      status: quote.status,
      customerName: quote.customer_name,
      serviceType: quote.service_type,
      pickupAddress: quote.pickup_address,
      dropoffAddress: quote.dropoff_address,
      serviceDate: quote.service_date,
      vehicleType: quote.vehicle_type,
      quoteTotal: Number(quote.quote_total),
      notes: quote.notes,
      createdAt: quote.created_at,
      tracking: {
        step: quote.status === 'accepted' ? 'Confirmed' : quote.status === 'pending' ? 'Awaiting approval' : 'Completed',
        progress: quote.status === 'accepted' ? 60 : quote.status === 'pending' ? 30 : 100,
        message: quote.status === 'accepted' ? 'Your booking is confirmed and the driver is assigned.' : quote.status === 'pending' ? 'We are reviewing your quote and will confirm shortly.' : 'Your trip is complete.'
      }
    };
  }

  const booking = await db.get('SELECT * FROM bookings WHERE id = ? AND LOWER(email) = ?', normalizedId, normalizedEmail);
  if (booking) {
    return {
      kind: 'booking',
      id: booking.id,
      email: booking.email,
      status: booking.status,
      customerName: booking.customer_name,
      serviceType: booking.service_type,
      pickupAddress: booking.pickup_address,
      dropoffAddress: booking.dropoff_address,
      serviceDate: booking.service_date,
      vehicleType: booking.vehicle_type,
      quoteTotal: Number(booking.quote_total),
      notes: booking.notes,
      createdAt: booking.created_at,
      tracking: {
        step: booking.status === 'booked' ? 'Driver assigned' : 'In progress',
        progress: booking.status === 'booked' ? 75 : 90,
        message: booking.status === 'booked' ? 'Your ride is confirmed and on the schedule.' : 'Your trip is underway.'
      }
    };
  }

  return null;
}

async function activityPush(entry) {
  await db.run('INSERT INTO activity (id, initials, name, action, detail, time, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    crypto.randomUUID(), entry.initials, entry.name, entry.action, entry.detail, entry.time, new Date().toISOString());
}

function isText(value) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= 500;
}

function rateLimit({ windowMs, max, name }) {
  pruneRateBuckets();
  return (req, res, next) => {
    const key = `${name}:${req.ip}`;
    const now = Date.now();
    const bucket = rateBuckets.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > bucket.resetAt) { bucket.count = 0; bucket.resetAt = now + windowMs; }
    bucket.count += 1;
    if (bucket.count > max) {
      const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);
      res.setHeader('Retry-After', String(retryAfter));
      return res.status(429).json({ error: 'Too many requests. Please try again shortly.' });
    }
    rateBuckets.set(key, bucket);
    next();
  };
}

function pruneRateBuckets() {
  const now = Date.now();
  for (const [key, bucket] of rateBuckets) {
    if (now > bucket.resetAt) rateBuckets.delete(key);
  }
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function emailName(value) {
  return String(value || '').split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()).trim() || 'Dispatcher';
}

function generateLicenseKey() {
  return `RZ-${crypto.randomBytes(16).toString('hex').toUpperCase()}`;
}

function normalizeLicenseKey(value) {
  return String(value || '').trim().toUpperCase();
}

function validateLicenseKey(value) {
  return /^RZ-[A-F0-9]{32}$/.test(normalizeLicenseKey(value));
}

async function createLicenseRecord({ userId, customerEmail, stripeSessionId = null, source = 'manual', licenseKey = null } = {}) {
  const record = {
    id: `LIC-${crypto.randomUUID()}`,
    userId: userId || null,
    licenseKey: normalizeLicenseKey(licenseKey || generateLicenseKey()),
    type: 'lifetime',
    status: 'active',
    stripeSessionId: stripeSessionId || null,
    customerEmail: customerEmail || null,
    source,
    createdAt: new Date().toISOString()
  };

  await db.run('INSERT INTO licenses (id, user_id, license_key, type, status, stripe_session_id, customer_email, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    record.id, record.userId, record.licenseKey, record.type, record.status, record.stripeSessionId, record.customerEmail, record.source, record.createdAt);
  return record;
}

async function findLicenseRecord(key, userId = null) {
  const normalized = normalizeLicenseKey(key);
  const row = await db.get('SELECT * FROM licenses WHERE license_key = ? AND status = ?', normalized, 'active');
  if (!row) return null;
  if (userId && row.user_id && row.user_id !== userId) return null;
  return { id: row.id, licenseKey: row.license_key, type: row.type, status: row.status, stripeSessionId: row.stripe_session_id, customerEmail: row.customer_email, source: row.source };
}

function getLicenseKeyFromRequest(req) {
  const header = req.headers['x-license-key'] || req.headers['X-License-Key'];
  const auth = req.headers.authorization;
  const fromBody = req.body && req.body.licenseKey ? req.body.licenseKey : '';
  const fromQuery = req.query && req.query.licenseKey ? req.query.licenseKey : '';
  return normalizeLicenseKey(header || (auth && auth.startsWith('Bearer ') ? auth.slice(7) : '') || fromBody || fromQuery);
}

async function hasValidLicense(user, suppliedKey = '') {
  if (!REQUIRE_LICENSE && !suppliedKey && !user) return true;
  if (user) {
    const row = await db.get('SELECT * FROM licenses WHERE user_id = ? AND status = ?', user.id, 'active');
    if (row) return true;
  }
  const key = normalizeLicenseKey(suppliedKey || DEMO_LICENSE_KEY);
  if (!key) return false;
  if (DEMO_LICENSE_KEY && normalizeLicenseKey(DEMO_LICENSE_KEY) === key) return true;
  return Boolean(await findLicenseRecord(key, user ? user.id : null));
}

async function buildAccountSummary(user) {
  const license = await db.get('SELECT * FROM licenses WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1', user.id, 'active');
  const plan = 'Lifetime';
  const status = license || user.role ? 'Active' : 'Inactive';
  const memberSince = (await db.get('SELECT created_at FROM users WHERE id = ?', user.id))?.created_at || new Date().toISOString();
  const billingAmount = (LIFETIME_PRICE_CENTS / 100).toFixed(2);

  return {
    userId: user.id,
    email: user.email,
    role: user.role,
    workspace: 'West Coast Fleet',
    plan,
    licenseStatus: status,
    memberSince,
    seats: 1,
    billing: {
      type: plan,
      status,
      amount: `$${billingAmount}`,
      currency: LIFETIME_CURRENCY.toUpperCase(),
      cycle: 'One-time purchase'
    },
    lastUpdated: new Date().toISOString()
  };
}

async function getAdminOverview() {
  const totalUsers = Number((await db.get('SELECT COUNT(*) as count FROM users'))?.count || 0);
  const activeLicenses = Number((await db.get('SELECT COUNT(*) as count FROM licenses WHERE status = ?', 'active'))?.count || 0);
  const totalRevenue = Number(((activeLicenses * LIFETIME_PRICE_CENTS) / 100).toFixed(2));

  return {
    totalUsers,
    activeLicenses,
    totalRevenue,
    trialUsers: Math.max(0, totalUsers - activeLicenses),
    currency: LIFETIME_CURRENCY.toUpperCase(),
    uptime: '99.9%'
  };
}

async function buildBillingSummary() {
  const overview = await getAdminOverview();
  const recurring = 0;
  return {
    plan: 'Lifetime',
    amount: '$499.00',
    currency: 'USD',
    monthlyRecurringRevenue: `$${recurring.toFixed(2)}`,
    annualRevenue: `$${overview.totalRevenue.toFixed(2)}`,
    activeCustomers: overview.activeLicenses,
    churnRate: '0.0%',
    nextInvoice: 'N/A',
    collectionStatus: 'Healthy'
  };
}

function createEmailVerificationToken(payload) {
  return jwt.sign({ userId: payload.id, email: payload.email, purpose: 'email_verification' }, JWT_SECRET, { expiresIn: '7d' });
}

function verifyEmailToken(token) {
  const decoded = jwt.verify(token, JWT_SECRET);
  if (decoded.purpose !== 'email_verification') {
    throw new Error('Invalid purpose');
  }
  return { userId: decoded.userId, email: decoded.email };
}

async function fulfillLifetimePurchase(session) {
  const existing = await db.get('SELECT * FROM licenses WHERE stripe_session_id = ?', session.id);
  if (existing) return { licenseKey: existing.license_key, type: existing.type, status: existing.status };
  return createLicenseRecord({
    userId: session.userId || null,
    customerEmail: session.customer_details?.email || session.customer_email || null,
    stripeSessionId: session.id,
    source: 'stripe'
  });
}

async function handleStripeWebhook(req, res) {
  if (!stripe || !stripeWebhookSecret) return res.status(503).send('Webhook is not configured');
  const signature = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, stripeWebhookSecret);
  } catch (error) {
    return res.status(400).send(`Webhook signature verification failed: ${error.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const isLifetimePurchase = session.metadata?.product === 'rz-dispatch' && session.metadata?.licenseType === 'lifetime';
    if (isLifetimePurchase && session.payment_status === 'paid') await fulfillLifetimePurchase(session);
  }
  res.json({ received: true });
}
